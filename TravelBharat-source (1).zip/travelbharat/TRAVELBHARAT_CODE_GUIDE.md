# TravelBharat Code Guide

TravelBharat is a React 19 + Vite frontend with a TypeScript Express/tRPC backend, Drizzle ORM, MySQL/TiDB persistence, Manus OAuth authentication, Google Maps integration, and optional Gemini recommendations.

## Included in this package

The archive contains the complete application source under `client/`, `server/`, `shared/`, and `drizzle/`, including destination discovery, state and destination detail pages, maps, authenticated Plan Trip, itinerary stops, hotel and transportation lookups, service selection persistence, booking requests, Gemini recommendation contracts, role-aware moderation, migrations, tests, scripts, and the TVS presentation project.

`node_modules`, local environment files, generated runtime logs, and sandbox-only build artifacts are intentionally excluded. Install dependencies locally with `pnpm install`.

## Local setup

1. Install Node.js 22 or a compatible current Node.js release and pnpm.
2. Run `pnpm install` from the project root.
3. Configure the database and required environment variables through the deployment or project management environment. Do not commit `.env` files or API keys.
4. Apply the existing Drizzle migrations through the project migration workflow. The migration history includes transportation fields and nullable itinerary hotel/transport selections.
5. Start development with `pnpm dev`.
6. Run `pnpm exec tsc --noEmit` and `pnpm test -- --run` before submitting changes.

## Important environment values

Public pages can run without analytics configuration. If `VITE_ANALYTICS_ENDPOINT` and `VITE_ANALYTICS_WEBSITE_ID` are absent, analytics is skipped safely and no placeholder request is sent. The backend requires the project database connection and authentication configuration for protected features. `OAUTH_SERVER_URL` is required for real sign-in, Plan Trip, and admin sessions; `DATABASE_URL` is required for database-backed records. Google Maps and Gemini behavior depends on the corresponding configured project integrations. Use the existing project environment mechanism rather than hardcoding credentials in source files.

## Main routes

`/` is the public homepage. `/discover` provides destination search and explainable recommendation entry. `/states` provides regional browsing. `/destinations/:slug` provides destination details, maps, galleries, hotels, transportation, and agent states. `/plan` is the protected itinerary workspace. `/admin` is the role-gated moderation workspace.

## Data integrity policy

The UI distinguishes published records, unavailable data, unpublished prices, and missing photos. Hotel and transportation records must come from verified provider or official source data. The current database audit found zero hotel rows; no hotel contacts, prices, reviews, or testimonials have been fabricated.

## Verification status

The current source passed TypeScript validation and the complete Vitest suite: **6 test files and 22 tests passed**. Browser checks covered public discovery, destination details, responsive layouts, anonymous Plan Trip/Admin entry states, and route-map entry behavior. Privileged administrator actions and a fully authenticated itinerary interaction session still require a signed-in test account.

## Assets and deck

Large visual assets should remain in managed storage according to the project workflow. The `tvs-epic-travelbharat-deck/` directory contains the current presentation source and slide state. The deck should be presented alongside the live prototype only after reviewing the current submission requirements.
