# TVS Credit E.P.I.C. 8.0 — Challenge Notes

Source: [Unstop competition page](https://unstop.com/competitions/crp-tvs-credit-epic-80-it-challenge-epic-season-8-tvs-credit-1701115), accessed 18 Aug 2026.

The page describes TVS Credit E.P.I.C. 8.0 as an online IT challenge for engineering, postgraduate, undergraduate, and management students. The team size is 1–2 members. The programme describes E.P.I.C. as Enrich, Perform, Innovate, Challenge, and presents the challenge as a way to apply technical knowledge to real-world business problems.

The published stages include a non-elimination demo assessment, a 20-question treasure hunt around TVS Credit and its product portfolio, a Round 1 assessment with programming fundamentals, financial literacy, and coding problems, a Round 2 case-study challenge, and a Grand Finale for shortlisted teams. The Round 2 requirement explicitly asks teams to propose solutions, explain the problems addressed, and present a framework or proof of concept through a PPT; the presentation may include a prototype, screens, or wireframe where required.

The page states prizes worth ₹2,50,000 and pre-placement interview opportunities. The deck should cite these only as challenge context, not as TravelBharat outcomes.

## Deck implication

TravelBharat should be presented as a proof-of-concept for a real-world travel-finance and discovery problem: reduce fragmented planning friction, make destination discovery more inclusive across India, and connect discovery to itinerary, maps, lodging, agent contact, and sandbox booking workflows. Implemented capabilities and roadmap capabilities must be separated explicitly.
