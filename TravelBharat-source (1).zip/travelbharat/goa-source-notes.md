# Goa destination source notes

The first nationwide directory validation batch will use official tourism sources rather than unsourced destination lists.

| Source | Verified information useful for import |
|---|---|
| [GTDC North Goa](https://goa-tourism.com/north-goa/) | North Goa page links to official sightseeing groups including beaches, Fort Aguada, markets, museums, Patto Bridge, science centres, the medical college, and the Immaculate Conception Church. |
| [GTDC Fort Aguada](https://goa-tourism.com/siteseeing/fort-aguada/) | Fort Aguada is described as a Portuguese fort in Sinquerim/Candolim, with an Aguada lighthouse and stated opening hours of 9:30 a.m. to 6:00 p.m. |
| [Incredible India: 20 Unique Things to Do in Goa](https://www.incredibleindia.gov.in/en/goa/goa/20-unique-things-to-do-in-goa-india) | The official tourism portal names Goa experiences and places including Galgibaga Beach, Cabo de Rama Fort, Dudhsagar Falls, Netravali, Chorla Ghats, Dr. Salim Ali Bird Sanctuary, Mollem National Park, Arvalem Caves, Usgalimal rock carvings, Fontainhas, and Mandovi River cruises. |
| [Department of Tourism, Government of Goa: Within Goa](https://goatourism.gov.in/within-goa/) | Official transport and access context for Goa, including ferry crossings such as Old Goa–Divar, Divar–Narve, Querim–Tiracol, and Cavelossim–Assolna. It also lists the department contact details and tourism helpline. |

These sources support destination names and regional context. Coordinates, individual image assets, entry fees, and timings must be verified per destination before database insertion. The project must not turn article experiences into destination records without checking that they represent a distinct visitable location.

## Initial rendering verification

The first Goa detail route for Fort Aguada rendered the destination-specific cover visual above the destination name and showed the correct Candolim, Goa location text. The Discover screenshot exposed the intended explicit `Loading photo…` state while the asset was still resolving; this is preferable to silently displaying an unrelated image. The Goa state route was captured during its loading state and requires a later post-resolution verification pass.

## Pending visual batch

The next five candidate Goa records are queued for a later image-generation window: Vagator Beach, Chapora Fort, Miramar Beach, Butterfly Beach, and a Bhagwan Mahavir-area waterfall. No destination records were inserted for this pending batch because each approved destination must receive its own TravelBharat-owned cover before publication.

## Search verification

The live Discover route now accepts `?search=Goa` and returns Goa destinations. The state name is displayed on the cards, and the first visible cards render distinct location-specific images above the destination content. This closes the earlier state-name search gap.

## Uploaded source extraction: goa-visiting-places.htm

The uploaded HTML is a Scribd-hosted document titled “goa visiting places,” with source URL https://www.scribd.com/document/644734310/goa-visiting-places. Its embedded description names thirteen Goa places: Calangute Beach, Baga Beach, Candolim Beach, Dudhsagar Waterfalls, Mangeshi Temple, Reis Magos Fort, Our Lady of the Immaculate Conception Church, Butterfly Beach, Splashdown Water Park, Mormugao Fort, Chapora Beach, Cabo De Rama Fort, and Arambol Beach. The document is treated as a source for place-name discovery only; its images are not copied because the uploaded HTML does not establish image reuse rights.
