import fs from "node:fs";
import path from "node:path";

const inputPath = process.argv[2];
if (!inputPath) {
  console.error("Usage: node scripts/validate-destination-batch.mjs <batch.json>");
  process.exit(2);
}

const filePath = path.resolve(inputPath);
const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
const records = Array.isArray(parsed) ? parsed : parsed?.records;
const errors = [];
const seenSlugs = new Set();
const seenImages = new Map();
const supportedCategories = new Set([
  "Beach",
  "City",
  "Culture",
  "Heritage",
  "Nature",
  "Picnic",
  "Spiritual",
  "Trekking",
  "Waterfall",
]);

if (!Array.isArray(records) || records.length === 0) {
  errors.push("Batch must be a non-empty JSON array or an object with a non-empty records array.");
}

for (const [index, record] of (records ?? []).entries()) {
  const label = `record ${index + 1}`;
  for (const field of ["slug", "stateSlug", "name", "category"]) {
    if (!record?.[field] || typeof record[field] !== "string") {
      errors.push(`${label}: ${field} is required.`);
    }
  }
  if (record?.slug && seenSlugs.has(record.slug)) errors.push(`${label}: duplicate slug ${record.slug}.`);
  if (record?.slug) seenSlugs.add(record.slug);
  if (record?.category && !supportedCategories.has(record.category)) errors.push(`${label}: unsupported category ${record.category}.`);

  const isPending = record?.status === "needs-record-and-photo" || record?.status === "photo-pending";
  if (!isPending) {
    if (!record?.primaryImage || typeof record.primaryImage !== "string") errors.push(`${label}: primaryImage is required unless the record is explicitly pending.`);
    if (!Number.isFinite(record?.latitude) || record.latitude < 6 || record.latitude > 36) errors.push(`${label}: latitude must be within India's bounds.`);
    if (!Number.isFinite(record?.longitude) || record.longitude < 68 || record.longitude > 98) errors.push(`${label}: longitude must be within India's bounds.`);
  } else if (record?.primaryImage) {
    errors.push(`${label}: pending records must not claim a primaryImage.`);
  }

  if (record?.primaryImage) {
    const previous = seenImages.get(record.primaryImage);
    if (previous) errors.push(`${label}: primaryImage is reused by ${previous}.`);
    seenImages.set(record.primaryImage, label);
  }
  if (!Array.isArray(record?.sources) || record.sources.length === 0) errors.push(`${label}: at least one source is required.`);
  for (const [sourceIndex, source] of (record?.sources ?? []).entries()) {
    if (!source?.url?.startsWith("http")) errors.push(`${label} source ${sourceIndex + 1}: valid URL is required.`);
    if (!source?.lastVerifiedAt) errors.push(`${label} source ${sourceIndex + 1}: lastVerifiedAt is required.`);
  }
}

if (errors.length) {
  console.error(errors.map((error) => `- ${error}`).join("\n"));
  process.exit(1);
}

console.log(`Validated ${records.length} destination records from ${filePath}`);
console.log(`Unique primary images: ${seenImages.size}`);
console.log(`Pending photo records: ${records.filter((record) => record.status === "needs-record-and-photo" || record.status === "photo-pending").length}`);
