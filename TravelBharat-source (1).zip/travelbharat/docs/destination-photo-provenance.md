# TravelBharat destination photo provenance

The first expanded destination photo set was generated in-project as original editorial travel imagery for the TravelBharat catalogue. The current set covers Gateway of India in Mumbai, Trimbakeshwar Temple near Nashik, Dashashwamedh Ghat in Varanasi, Virupaksha Temple in Hampi, and Meenakshi Amman Temple in Madurai.

These assets are referenced through the project-managed storage paths recorded in the `destinations.image` and `destinationGallery.imageUrl` fields. They do not depend on scraped third-party image URLs. The UI supplies descriptive alternative text for accessibility, and destination pages identify the images as travel photographs rather than presenting them as official government or tourism-board photographs.

Future photographs sourced from external tourism boards, Wikimedia Commons, photographers, or booking providers must be added only after recording the source URL, license or permission status, photographer credit where required, and retrieval date in the gallery metadata or accompanying content record. The project should not describe an asset as official unless its source explicitly establishes that status.
