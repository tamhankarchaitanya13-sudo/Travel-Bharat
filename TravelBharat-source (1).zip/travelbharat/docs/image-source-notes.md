# Image source notes

TravelBharat destination cards use project-managed image assets. The five previously missing cards were temporarily checked with search-result candidates during development, but their database records now reference TravelBharat-owned generated assets. The gallery rows are synchronized with the corresponding primary image.

## Auditable owned-asset mapping

| Destination slug | Destination | Primary image URL | Gallery image URL | Match status | Alt text status |
|---|---|---|---|---|---|
| `darjeeling` | Darjeeling | `/manus-storage/darjeeling-owned_83125bc5.jpg` | `/manus-storage/darjeeling-owned_83125bc5.jpg` | Match | Present |
| `manali` | Manali | `/manus-storage/manali-owned_02d41015.jpg` | `/manus-storage/manali-owned_02d41015.jpg` | Match | Present |
| `munnar` | Munnar | `/manus-storage/munnar-owned_6f32b499.jpg` | `/manus-storage/munnar-owned_6f32b499.jpg` | Match | Present |
| `panaji` | Panaji | `/manus-storage/panaji-owned_98931b77.jpg` | `/manus-storage/panaji-owned_98931b77.jpg` | Match | Present |
| `varanasi` | Varanasi | `/manus-storage/varanasi-owned_f0439471.jpg` | `/manus-storage/varanasi-owned_f0439471.jpg` | Match | Present |

The mapping above was checked against the `destinations` and `destinationGallery` tables. The gallery alt text follows the pattern “{Destination} TravelBharat original destination photograph.” Older search-result candidates are retained only in development provenance history and are not referenced by these current destination records.

## Asset policy

Images used in the catalogue should be project-managed or otherwise license-verified. Every published destination should have a primary image, a synchronized gallery image, and descriptive alternative text. If an asset is not yet available, the catalogue must show an explicit unavailable state rather than silently reusing an unrelated destination photograph.

## Verification date

The five-row database comparison and URL-match audit were completed on 2026-08-07.

> Note: The `/manus-storage/` paths are project-managed storage paths used by the TravelBharat application; they are not external search-result URLs.

## Full-catalogue audit status

The broader catalogue audit separately verified zero duplicate primary-image assignments, zero primary-image gaps, zero primary-to-gallery URL mismatches, zero missing gallery rows, and zero missing gallery alt-text values for the current inventory.

## Source traceability

The owned generated assets were created for TravelBharat and assigned to the corresponding destination records. The provenance file documents the final database mappings rather than temporary development candidates.

## Current coverage note

TravelBharat currently has a nationwide foundation covering all 36 Indian state and union-territory regions in the database, with a representative 50-destination inventory. Expanding to every small local place remains a separate catalogue-growth task; this note does not claim exhaustive coverage of every geographic attraction in India.

## Content integrity

No customer reviews, ratings, or testimonials are fabricated in this image provenance workflow.


## Goa generated-illustration batch

The first generated-asset batch for the nationwide expansion contains five destination-specific TravelBharat-owned illustrations. They are visual aids for destination cards, not documentary photographs.

| Destination slug | Destination | Primary image URL | Asset type | Match status |
|---|---|---|---|---|
| `fort-aguada` | Fort Aguada | `/manus-storage/goa-fort-aguada-owned_a5a01f34.jpg` | TravelBharat-owned generated illustration | Reserved |
| `dudhsagar-falls` | Dudhsagar Falls | `/manus-storage/goa-dudhsagar-falls-owned_a4792b48.jpg` | TravelBharat-owned generated illustration | Reserved |
| `fontainhas` | Fontainhas | `/manus-storage/goa-fontainhas-owned_0b5259d6.jpg` | TravelBharat-owned generated illustration | Reserved |
| `dr-salim-ali-bird-sanctuary` | Dr. Salim Ali Bird Sanctuary | `/manus-storage/goa-salim-ali-bird-sanctuary-owned_433336d2.jpg` | TravelBharat-owned generated illustration | Reserved |
| `cabo-de-rama` | Cabo de Rama Fort | `/manus-storage/goa-cabo-de-rama-owned_335d1ce4.jpg` | TravelBharat-owned generated illustration | Reserved |

The application may display these visuals without an intrusive badge, but project documentation must keep the provenance clear and the UI must not describe them as user-taken or documentary photographs. Each URL must be assigned only to the matching destination record.
