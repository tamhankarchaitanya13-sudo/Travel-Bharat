import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: undefined,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("tourism catalogue", () => {
  it("exposes states and destinations through public procedures", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const [states, destinations] = await Promise.all([caller.tourism.states(), caller.tourism.destinations({})]);
    expect(states.length).toBeGreaterThan(0);
    expect(destinations.length).toBeGreaterThan(0);
    expect(destinations[0]).toHaveProperty("stateName");
  });

  it("returns a stable truthful recommendation fallback when no destination matches", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.tourism.recommendationBrief({ category: "Not a real category" });
    expect(result.recommendations.length).toBeGreaterThan(0);
    expect(result.recommendations[0]).toHaveProperty("slug");
    expect(result.explanation.length).toBeGreaterThan(0);
    expect(typeof result.generated).toBe("boolean");
  });

  it("supports destination lookup by slug", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const destination = await caller.tourism.destinationBySlug({ slug: "udaipur" });
    expect(destination?.name).toBe("Udaipur");
    expect(destination?.stateName).toBe("Rajasthan");
  });
});
