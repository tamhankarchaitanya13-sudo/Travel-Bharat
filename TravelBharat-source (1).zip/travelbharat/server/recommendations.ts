import type { Destination } from "../drizzle/schema";

type RecommendationInput = {
  category?: string;
  stateName?: string;
  budget?: "low" | "mid" | "high";
};

function budgetScore(value: string) {
  const numeric = Number(value.replace(/[^0-9]/g, ""));
  if (!Number.isFinite(numeric)) return 1;
  if (numeric < 7000) return 0;
  if (numeric < 9000) return 1;
  return 2;
}

export function recommendDestinations<T extends Destination & { stateName: string }>(destinations: T[], input: RecommendationInput) {
  const targetBudget = input.budget === "low" ? 0 : input.budget === "high" ? 2 : 1;
  return destinations
    .map((destination) => {
      let score = 0;
      if (input.category && destination.category === input.category) score += 4;
      if (input.stateName && destination.stateName === input.stateName) score += 3;
      score += Math.max(0, 2 - Math.abs(budgetScore(destination.budget) - targetBudget));
      return { destination, score };
    })
    .sort((a, b) => b.score - a.score || a.destination.name.localeCompare(b.destination.name))
    .map(({ destination }) => destination);
}
