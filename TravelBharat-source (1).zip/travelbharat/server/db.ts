import { and, asc, count, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { Booking, Destination, DestinationGallery, Hotel, InsertUser, Itinerary, ItineraryItem, TravelAgent, Transportation, bookings, destinationGallery, destinations, hotels, itineraryItems, itineraries, states, transportation, travelAgents, State, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getModerationQueue() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ destination: destinations, stateName: states.name })
    .from(destinations)
    .leftJoin(states, eq(destinations.stateId, states.id))
    .where(or(eq(destinations.moderationStatus, "draft"), eq(destinations.moderationStatus, "needs_review")))
    .orderBy(desc(destinations.updatedAt), asc(destinations.name));
}

export async function updateDestinationModeration(destinationId: number, moderationStatus: "draft" | "published" | "needs_review") {
  const db = await getDb();
  if (!db) return undefined;
  await db.update(destinations).set({ moderationStatus }).where(eq(destinations.id, destinationId));
  const rows = await db.select().from(destinations).where(eq(destinations.id, destinationId)).limit(1);
  return rows[0];
}

export async function getStates(): Promise<State[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(states).orderBy(asc(states.name));
}

export async function getStateDirectory() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ state: states, destinationCount: count(destinations.id), missingImageCount: sql<number>`sum(case when ${destinations.image} is null or ${destinations.image} = '' then 1 else 0 end)` }).from(states).leftJoin(destinations, eq(destinations.stateId, states.id)).groupBy(states.id).orderBy(asc(states.name));
  return rows.map((row) => ({ ...row.state, destinationCount: Number(row.destinationCount), missingImageCount: Number(row.missingImageCount ?? 0) }));
}

export async function getDestinations(search?: string, category?: string): Promise<(Destination & { stateName: string })[]> {
  const db = await getDb();
  if (!db) return [];
  const filters = [];
  if (search) filters.push(or(like(destinations.name, `%${search}%`), like(destinations.category, `%${search}%`), like(states.name, `%${search}%`)));
  if (category && category !== "All") filters.push(eq(destinations.category, category));
  const query = db.select({ destination: destinations, stateName: states.name }).from(destinations).leftJoin(states, eq(destinations.stateId, states.id)).orderBy(asc(destinations.name));
  const rows = filters.length ? await query.where(and(...filters)) : await query;
  return rows.map((row) => ({ ...row.destination, stateName: row.stateName ?? "" }));
}

const FEATURED_DESTINATION_SLUGS = [
  "udaipur",
  "munnar",
  "manali",
  "panaji",
  "darjeeling",
  "randha-falls",
  "tarkarli-beach",
  "araku-valley",
] as const;

export async function getFeaturedDestinations(limit = 8): Promise<(Destination & { stateName: string })[]> {
  const all = await getDestinations();
  const bySlug = new Map(all.map((destination) => [destination.slug, destination]));
  return FEATURED_DESTINATION_SLUGS.map((slug) => bySlug.get(slug)).filter(
    (destination): destination is Destination & { stateName: string } => Boolean(destination?.image),
  ).slice(0, Math.max(1, Math.min(limit, FEATURED_DESTINATION_SLUGS.length)));
}

export async function getDestinationGallery(destinationId: number): Promise<DestinationGallery[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(destinationGallery).where(eq(destinationGallery.destinationId, destinationId)).orderBy(asc(destinationGallery.sortOrder), asc(destinationGallery.id));
}

export async function createItinerary(input: { userId: number; name: string; startDate?: string; endDate?: string; notes?: string; status?: "draft" | "planned" | "completed" }): Promise<Itinerary> {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(itineraries).values(input);
  const created = await db.select().from(itineraries).where(eq(itineraries.id, Number(result[0].insertId))).limit(1);
  if (!created[0]) throw new Error("Failed to create itinerary");
  return created[0];
}

export async function listItineraries(userId: number): Promise<(Itinerary & { items: ItineraryItem[] })[]> {
  const db = await getDb();
  if (!db) return [];
  const plans = await db.select().from(itineraries).where(eq(itineraries.userId, userId)).orderBy(asc(itineraries.createdAt));
  const result: (Itinerary & { items: ItineraryItem[] })[] = [];
  for (const plan of plans) {
    const items = await db.select().from(itineraryItems).where(eq(itineraryItems.itineraryId, plan.id)).orderBy(asc(itineraryItems.dayNumber), asc(itineraryItems.sortOrder));
    result.push({ ...plan, items });
  }
  return result;
}

export async function addItineraryItem(input: { userId: number; itineraryId: number; destinationId: number; dayNumber: number; sortOrder?: number; notes?: string }): Promise<ItineraryItem> {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const owner = await db.select({ id: itineraries.id }).from(itineraries).where(and(eq(itineraries.id, input.itineraryId), eq(itineraries.userId, input.userId))).limit(1);
  if (!owner[0]) throw new Error("Itinerary not found");
  const result = await db.insert(itineraryItems).values({ itineraryId: input.itineraryId, destinationId: input.destinationId, dayNumber: input.dayNumber, sortOrder: input.sortOrder ?? 0, notes: input.notes });
  const created = await db.select().from(itineraryItems).where(eq(itineraryItems.id, Number(result[0].insertId))).limit(1);
  if (!created[0]) throw new Error("Failed to add itinerary item");
  return created[0];
}

export async function selectItineraryServices(input: { userId: number; itineraryItemId: number; hotelId?: number | null; transportationId?: number | null }): Promise<ItineraryItem | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const ownedItem = await db.select({ item: itineraryItems, itineraryUserId: itineraries.userId }).from(itineraryItems).innerJoin(itineraries, eq(itineraryItems.itineraryId, itineraries.id)).where(and(eq(itineraryItems.id, input.itineraryItemId), eq(itineraries.userId, input.userId))).limit(1);
  const row = ownedItem[0];
  if (!row) return undefined;

  const values: { hotelId?: number | null; transportationId?: number | null } = {};
  if (input.hotelId !== undefined) {
    if (input.hotelId !== null) {
      const hotel = await db.select({ id: hotels.id }).from(hotels).where(and(eq(hotels.id, input.hotelId), eq(hotels.destinationId, row.item.destinationId))).limit(1);
      if (!hotel[0]) throw new Error("Hotel option does not belong to this destination");
    }
    values.hotelId = input.hotelId;
  }
  if (input.transportationId !== undefined) {
    if (input.transportationId !== null) {
      const transport = await db.select({ id: transportation.id }).from(transportation).where(and(eq(transportation.id, input.transportationId), eq(transportation.destinationId, row.item.destinationId), eq(transportation.moderationStatus, "published" as const))).limit(1);
      if (!transport[0]) throw new Error("Transportation option does not belong to this destination or is not published");
    }
    values.transportationId = input.transportationId;
  }
  if (Object.keys(values).length === 0) throw new Error("Select a hotel or transportation option");
  await db.update(itineraryItems).set(values).where(eq(itineraryItems.id, input.itineraryItemId));
  const updated = await db.select().from(itineraryItems).where(eq(itineraryItems.id, input.itineraryItemId)).limit(1);
  return updated[0];
}

export async function createBooking(input: Omit<Booking, "id" | "createdAt" | "updatedAt">): Promise<Booking> {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(bookings).values(input);
  const created = await db.select().from(bookings).where(eq(bookings.id, Number(result[0].insertId))).limit(1);
  if (!created[0]) throw new Error("Failed to create booking");
  return created[0];
}

export async function listBookings(userId: number): Promise<Booking[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookings).where(eq(bookings.userId, userId)).orderBy(asc(bookings.createdAt));
}

export async function getHotelsByDestination(destinationId: number): Promise<Hotel[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hotels).where(eq(hotels.destinationId, destinationId)).orderBy(asc(hotels.name));
}

export async function getTravelAgentsByDestination(destinationId?: number): Promise<TravelAgent[]> {
  const db = await getDb();
  if (!db) return [];
  const filters = [eq(travelAgents.moderationStatus, "published" as const)];
  if (destinationId) filters.push(eq(travelAgents.destinationId, destinationId));
  return db.select().from(travelAgents).where(and(...filters)).orderBy(asc(travelAgents.name));
}

export async function getTransportationByDestination(destinationId: number, mode?: Transportation["mode"]): Promise<Transportation[]> {
  const db = await getDb();
  if (!db) return [];
  const filters = [
    eq(transportation.destinationId, destinationId),
    eq(transportation.moderationStatus, "published" as const),
  ];
  if (mode) filters.push(eq(transportation.mode, mode));
  return db.select().from(transportation).where(and(...filters)).orderBy(asc(transportation.mode), asc(transportation.provider));
}

export async function getItineraryRoute(userId: number, itineraryId: number) {
  const details = await getItineraryDetails(userId, itineraryId);
  if (!details) return undefined;
  return {
    itineraryId: details.id,
    name: details.name,
    stops: details.items.map((item) => ({
      itineraryItemId: item.id,
      destinationId: item.destinationId,
      destinationName: item.destination.name,
      destinationSlug: item.destination.slug,
      latitude: item.destination.latitude,
      longitude: item.destination.longitude,
      dayNumber: item.dayNumber,
      sortOrder: item.sortOrder,
    })),
  };
}

export async function getItineraryDetails(userId: number, itineraryId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const plan = await db.select().from(itineraries).where(and(eq(itineraries.id, itineraryId), eq(itineraries.userId, userId))).limit(1);
  if (!plan[0]) return undefined;
  const items = await db.select({ item: itineraryItems, destination: destinations, stateName: states.name }).from(itineraryItems).innerJoin(destinations, eq(itineraryItems.destinationId, destinations.id)).leftJoin(states, eq(destinations.stateId, states.id)).where(eq(itineraryItems.itineraryId, itineraryId)).orderBy(asc(itineraryItems.dayNumber), asc(itineraryItems.sortOrder));
  const enrichedItems = [];
  for (const row of items) {
    const [hotelOptions, agentOptions, transportationOptions] = await Promise.all([
      getHotelsByDestination(row.destination.id),
      getTravelAgentsByDestination(row.destination.id),
      getTransportationByDestination(row.destination.id),
    ]);
    enrichedItems.push({ ...row.item, destination: { ...row.destination, stateName: row.stateName ?? "" }, hotels: hotelOptions, agents: agentOptions, transportation: transportationOptions });
  }
  return { ...plan[0], items: enrichedItems };
}

export async function getDestinationBySlug(slug: string): Promise<(Destination & { stateName: string }) | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select({ destination: destinations, stateName: states.name }).from(destinations).leftJoin(states, eq(destinations.stateId, states.id)).where(eq(destinations.slug, slug)).limit(1);
  const row = rows[0];
  return row ? { ...row.destination, stateName: row.stateName ?? "" } : undefined;
}
