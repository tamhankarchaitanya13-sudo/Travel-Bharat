import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(user?: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("authenticated trip APIs", () => {
  it("rejects anonymous moderation access", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.admin.moderationQueue()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects ordinary users from moderation access", async () => {
    const caller = appRouter.createCaller(createContext({ id: 999999, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.admin.moderationQueue()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects anonymous itinerary creation", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.createItinerary({ name: "Weekend plan" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects anonymous service selection", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.selectServices({ itineraryItemId: 1, hotelId: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires at least one service when selecting itinerary options", async () => {
    const caller = appRouter.createCaller(createContext({ id: 999999, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.trips.selectServices({ itineraryItemId: 1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("does not update a trip stop that is missing or owned by another user", async () => {
    const caller = appRouter.createCaller(createContext({ id: 999999, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.trips.selectServices({ itineraryItemId: 999999, hotelId: 1 })).resolves.toBeUndefined();
  });

  it("rejects anonymous booking requests", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.requestBooking({
      travelerName: "Visitor",
      travelerEmail: "visitor@example.com",
      travelersCount: 2,
    })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects anonymous itinerary detail access", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.itineraryDetails({ itineraryId: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects anonymous route-overview access", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.routeOverview({ itineraryId: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("does not expose route coordinates for an inaccessible itinerary", async () => {
    const caller = appRouter.createCaller(createContext({ id: 999999, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.trips.routeOverview({ itineraryId: 999999 })).resolves.toBeUndefined();
  });

  it("keeps travel-agent lookup publicly readable for Explore", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.travelAgents({ destinationId: 1 })).resolves.toBeInstanceOf(Array);
  });

  it("returns no enriched itinerary details for an itinerary the signed-in user cannot access", async () => {
    const caller = appRouter.createCaller(createContext({ id: 999999, openId: "test-user", name: "Test User", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.trips.itineraryDetails({ itineraryId: 999999 })).resolves.toBeUndefined();
  });

  it("keeps hotel lookup publicly readable for destination planning", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.hotels({ destinationId: 1 })).resolves.toBeInstanceOf(Array);
  });

  it("keeps transportation lookup publicly readable for destination planning", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.trips.transportation({ destinationId: 1 })).resolves.toBeInstanceOf(Array);
  });
});
