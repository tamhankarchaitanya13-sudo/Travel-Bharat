import { describe, expect, it } from "vitest";
import { recommendDestinations } from "./recommendations";

describe("recommendDestinations", () => {
  const destinations = [
    { name: "Udaipur", category: "Heritage", stateName: "Rajasthan", budget: "₹8,500" },
    { name: "Munnar", category: "Nature", stateName: "Kerala", budget: "₹7,200" },
    { name: "Varanasi", category: "Spiritual", stateName: "Uttar Pradesh", budget: "₹5,400" },
  ] as never[];

  it("prioritizes matching category and state", () => {
    const result = recommendDestinations(destinations, { category: "Heritage", stateName: "Rajasthan", budget: "mid" });
    expect(result[0]?.name).toBe("Udaipur");
  });

  it("prioritizes lower-cost destinations for a low budget", () => {
    const result = recommendDestinations(destinations, { budget: "low" });
    expect(result[0]?.name).toBe("Varanasi");
  });
});
