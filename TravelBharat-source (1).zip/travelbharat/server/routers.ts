import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { recommendDestinations } from "./recommendations";
import { invokeLLM } from "./_core/llm";
import { addItineraryItem, createBooking, createItinerary, getDestinationBySlug, getDestinationGallery, getDestinations, getFeaturedDestinations, getHotelsByDestination, getItineraryDetails, getItineraryRoute, getModerationQueue, getStateDirectory, getStates, getTransportationByDestination, getTravelAgentsByDestination, listBookings, listItineraries, selectItineraryServices, updateDestinationModeration } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  tourism: router({
    states: publicProcedure.query(() => getStates()),
    stateDirectory: publicProcedure.query(() => getStateDirectory()),
    destinations: publicProcedure.input(z.object({ search: z.string().optional(), category: z.string().optional() }).optional()).query(({ input }) => getDestinations(input?.search, input?.category)),
    featuredDestinations: publicProcedure.input(z.object({ limit: z.number().int().min(1).max(8).optional() }).optional()).query(({ input }) => getFeaturedDestinations(input?.limit)),
    destinationBySlug: publicProcedure.input(z.object({ slug: z.string().min(1) })).query(({ input }) => getDestinationBySlug(input.slug)),
    destinationGallery: publicProcedure.input(z.object({ destinationId: z.number().int().positive() })).query(({ input }) => getDestinationGallery(input.destinationId)),
    recommendations: publicProcedure.input(z.object({ category: z.string().optional(), stateName: z.string().optional(), budget: z.enum(["low", "mid", "high"]).optional() }).optional()).query(async ({ input }) => recommendDestinations(await getDestinations(), input ?? {})),
    recommendationBrief: publicProcedure.input(z.object({ category: z.string().optional(), stateName: z.string().optional(), budget: z.enum(["low", "mid", "high"]).optional() }).optional()).query(async ({ input }) => {
      const shortlist = recommendDestinations(await getDestinations(), input ?? {}).slice(0, 4).map((destination) => ({ slug: destination.slug, name: destination.name, state: destination.stateName, category: destination.category, budget: destination.budget, description: destination.description }));
      if (!shortlist.length) return { recommendations: [], explanation: "No destinations match these preferences yet.", generated: false };
      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You explain a deterministic travel shortlist. Use only the supplied destination fields and preferences. Do not invent prices, opening hours, availability, ratings, transport, hotels, or facts. Return concise plain-language reasons for the ordering." },
            { role: "user", content: JSON.stringify({ preferences: input ?? {}, shortlist }) },
          ],
          response_format: { type: "json_schema", json_schema: { name: "recommendation_brief", strict: true, schema: { type: "object", properties: { explanation: { type: "string" } }, required: ["explanation"], additionalProperties: false } } },
        });
        const content = response.choices?.[0]?.message?.content;
        const parsed = typeof content === "string" ? JSON.parse(content) as { explanation?: string } : null;
        return { recommendations: shortlist, explanation: parsed?.explanation || "These destinations were ordered using your selected travel style, region, and budget.", generated: Boolean(parsed?.explanation) };
      } catch {
        return { recommendations: shortlist, explanation: "These destinations were ordered using TravelBharat’s transparent category, region, and budget matching. AI explanation is temporarily unavailable.", generated: false };
      }
    }),
  }),

  trips: router({
    listItineraries: protectedProcedure.query(({ ctx }) => listItineraries(ctx.user.id)),
    createItinerary: protectedProcedure.input(z.object({
      name: z.string().min(1).max(160),
      startDate: z.string().max(32).optional(),
      endDate: z.string().max(32).optional(),
      notes: z.string().max(5000).optional(),
      status: z.enum(["draft", "planned", "completed"]).optional(),
    })).mutation(({ ctx, input }) => createItinerary({ ...input, userId: ctx.user.id })),
    addStop: protectedProcedure.input(z.object({
      itineraryId: z.number().int().positive(),
      destinationId: z.number().int().positive(),
      dayNumber: z.number().int().min(1).max(365),
      sortOrder: z.number().int().min(0).optional(),
      notes: z.string().max(2000).optional(),
    })).mutation(({ ctx, input }) => addItineraryItem({ ...input, userId: ctx.user.id })),
    selectServices: protectedProcedure.input(z.object({
      itineraryItemId: z.number().int().positive(),
      hotelId: z.number().int().positive().nullable().optional(),
      transportationId: z.number().int().positive().nullable().optional(),
    }).refine((input) => input.hotelId !== undefined || input.transportationId !== undefined, { message: "Select a hotel or transportation option" })).mutation(({ ctx, input }) => selectItineraryServices({ ...input, userId: ctx.user.id })),
    listBookings: protectedProcedure.query(({ ctx }) => listBookings(ctx.user.id)),
    requestBooking: protectedProcedure.input(z.object({
      itineraryId: z.number().int().positive().optional(),
      destinationId: z.number().int().positive().optional(),
      travelerName: z.string().min(1).max(160),
      travelerEmail: z.string().email().max(320),
      travelersCount: z.number().int().min(1).max(100),
      travelDate: z.string().max(32).optional(),
      notes: z.string().max(3000).optional(),
    })).mutation(({ ctx, input }) => createBooking({
      userId: ctx.user.id,
      itineraryId: input.itineraryId ?? null,
      destinationId: input.destinationId ?? null,
      travelerName: input.travelerName,
      travelerEmail: input.travelerEmail,
      travelersCount: input.travelersCount,
      travelDate: input.travelDate ?? null,
      notes: input.notes ?? null,
      status: "requested",
    })),
    hotels: publicProcedure.input(z.object({ destinationId: z.number().int().positive() })).query(({ input }) => getHotelsByDestination(input.destinationId)),
    travelAgents: publicProcedure.input(z.object({ destinationId: z.number().int().positive().optional() }).optional()).query(({ input }) => getTravelAgentsByDestination(input?.destinationId)),
    transportation: publicProcedure.input(z.object({ destinationId: z.number().int().positive(), mode: z.enum(["flight", "train", "bus", "local_rental"]).optional() })).query(({ input }) => getTransportationByDestination(input.destinationId, input.mode)),
    itineraryDetails: protectedProcedure.input(z.object({ itineraryId: z.number().int().positive() })).query(({ ctx, input }) => getItineraryDetails(ctx.user.id, input.itineraryId)),
    routeOverview: protectedProcedure.input(z.object({ itineraryId: z.number().int().positive() })).query(({ ctx, input }) => getItineraryRoute(ctx.user.id, input.itineraryId)),
  }),

  admin: router({
    moderationQueue: adminProcedure.query(() => getModerationQueue()),
    updateDestinationStatus: adminProcedure.input(z.object({ destinationId: z.number().int().positive(), moderationStatus: z.enum(["draft", "published", "needs_review"]) })).mutation(({ input }) => updateDestinationModeration(input.destinationId, input.moderationStatus)),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
