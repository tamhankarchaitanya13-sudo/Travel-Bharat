# TravelBharat Revised 15-Day Roadmap

## Scope decision

The uploaded recording defines phase one as an informational tourism platform. The implementation will prioritize state-wise and city-wise destination discovery, structured destination details, search and filtering, responsive design, gallery/media, and admin content management. Real-time booking and online payments are excluded from phase one unless the internship supervisor provides a newer written requirement.

## Day-by-day plan

| Days | Focus | Deliverable |
|---|---|---|
| 1–2 | Requirements, database fields, route map, and UI wireframes | Approved scope, schema additions, and page plan |
| 3 | Complete state, city, and category data model | Database supports official input fields |
| 4–5 | Destination details | Description, historical significance, best time, entry fee, timings, nearby attractions, map link, and city fields |
| 6 | Search and discovery | Search by place, state, city, and category with combined filters |
| 7 | Gallery and media | Destination gallery with accessible image captions and empty states |
| 8–9 | Admin dashboard | Add, edit, delete, preview, and moderate destination content |
| 10 | Content validation | Required-field validation, safe input handling, and moderation status |
| 11 | Responsive UI | Mobile, tablet, and desktop layout verification |
| 12 | Map and future-scope boundaries | Keep the existing map as an enhancement; ensure informational pages work without booking or payment dependencies |
| 13 | Testing | Backend procedure tests, form validation tests, navigation tests, and empty/error-state checks |
| 14 | Documentation | PRD, SRS sections, ER diagram, use-case diagram, screenshots, test cases, and limitations |
| 15 | Final presentation | Demo script, project report, final review, and submission package |

## Required data fields

Each destination should support the name, state, city, category, description, historical significance, best time to visit, entry fee, opening and closing timings, nearby attractions, map coordinates or map link, gallery images, moderation status, and an administrator update timestamp.

## Deferred features

Payment processing, real-time bookings, hotel and transport integrations, multilingual content, and advanced machine-learning recommendations should be documented under future scope unless the supervisor specifically confirms that they are mandatory for this phase.

## Success criteria

The phase-one application is complete when a visitor can browse states and cities, search and filter destinations, open a detailed destination page, view its gallery and structured travel information, and use the site comfortably on mobile and desktop. An administrator must be able to manage and moderate the destination content through the dashboard.
