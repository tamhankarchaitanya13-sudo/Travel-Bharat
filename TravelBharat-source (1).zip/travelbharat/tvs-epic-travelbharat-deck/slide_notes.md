# 1 - TravelBharat

We are not building another generic list of tourist places. We are building the decision layer between curiosity and a completed trip. TravelBharat turns fragmented travel discovery into one confident, visual, and actionable journey across India. Discover, plan, and move. Let us show you how we solve the travel planning gap. And to understand why this matters, let us look at the challenge context.

# 2 - The challenge context

Our response to the TVS Credit E.P.I.C. 8.0 challenge is a working prototype, not just a concept poster. Travel planning in India is notoriously fragmented today across multiple disjointed apps and websites. We bring a working platform with database-backed destinations, maps, and itineraries to solve this exact friction. Moving forward, let us examine where travelers experience this tension firsthand.

# 3 - Inspiration is abundant. Confidence is scarce.

Inspiration is abundant in travel today, but true confidence is scarce. Travelers constantly pause because generic lists hide small places and planning tools are hopelessly split across tabs. TravelBharat responds with state-aware discovery and an authenticated itinerary studio to replace doubt with clarity. This naturally leads us to our core product promise.

# 4 - One discovery layer, one private trip studio

We deliver one India-wide discovery layer paired with a private trip studio. You can explore by category, understand places through maps and practical details, plan daily stops, and connect with verified local partners. Everything culminates in a clean sandbox action without pretending to process live payments. Let us now walk through how this looks in practice.

# 5 - From “Where should I go?” to “My trip is ready.”

This is how we move a traveler from wondering where to go to having a ready trip. We start with a simple homepage search, browse state-aware results, and inspect rich destination details. Then we build a private day-by-day itinerary and test the sandbox booking flow. Keep this exact sequence in mind as we evaluate what is already live in our codebase today.

# 6 - Proof of concept: the core loop is live

We are not showing wireframes or concept mockups. The core loop is live in a working React and tRPC application today. And that matters because you can test the database-backed states, explore destinations, and build a private itinerary right now. Notice how we keep our claims disciplined; unbuilt features like live Gemini recommendations stay strictly on the roadmap. So let us look at the practical stack that powers this performance.

# 7 - A practical stack designed to scale

We built this on a practical, type-safe stack designed to scale gracefully from prototype to nationwide product. And here is how the data flows: React and Tailwind handle the photo-first interface, while typed tRPC procedures connect directly to our MySQL database via Drizzle ORM. Notice how we isolate external services like Google Maps and S3 asset storage so the application stays fast and responsive. But a great stack needs the right content model to matter.

# 8 - Built for the long tail of India

Travel planning in India usually stops at the top ten famous monuments. But TravelBharat is built for the long tail of the country, from small hill stations and hidden waterfalls to regional temples and local heritage. Our Goa batch proves this catalog model with twenty source-backed destination records and explicit photo-pending states. So we scale this same structured approach across all thirty-six regions without faking coverage. And none of this works if we compromise on honesty.

# 9 - Useful technology without pretending certainty

Travel technology often fails because it pretends to know more than it does. We refuse to fabricate reviews, invent hotel contacts, or pass off generated illustrations as documentary photography. Private itinerary mutations stay protected, and booking requests remain clearly sandboxed in the prototype. Trust is our core product feature, because real confidence comes from clear boundaries. So let us examine the business pathway this trust unlocks.

# 10 - From discovery utility to a travel-finance opportunity

Building a trusted travel platform opens up meaningful opportunities for the entire ecosystem. By organizing travel intent and structured discovery, we create value that extends from the individual traveler to local partners. We earn the right to introduce relevant financial and partner services by first establishing genuine travel confidence. Notice how this value grows outward from a reliable discovery layer to broader ecosystem participation. And that structured pathway leads directly into our execution timeline.

# 11 - Build the national index, then make it intelligent

Our growth strategy follows a disciplined sequence of building the foundation before adding intelligence. We start by making every region findable with a solid starter set of destinations and verified coordinates. Then we deepen local context with rich visuals and early recommendation features before opening up conversion workflows. Every milestone is measured against strict data completeness rather than empty feature checklists. This phased roadmap ensures the platform scales with absolute reliability.

# 12 - Make every Indian journey easier to begin.

TravelBharat turns fragmented travel search into a confident and actionable journey. We started with a clear problem and built a working proof of concept that solves it. Let us walk through the live demo sequence in three minutes, starting from a simple search on the homepage. Watch how the system guides you from inspiration to a saved itinerary and a sandbox booking request without false payment claims. Thank you for your time, and we invite your questions.
