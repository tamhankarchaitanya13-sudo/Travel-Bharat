import { useMemo, useState } from "react";
import { Link } from "wouter";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowRight, Compass, Map, Menu, Search, Sparkles, Utensils, Waves, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { states } from "@/data/travel";
import { trpc } from "@/lib/trpc";

const destinations = [
  { name: "Udaipur", state: "Rajasthan", category: "Heritage", budget: "₹8,500", tone: "from-orange-950 via-orange-700 to-amber-300", icon: Compass, image: "/manus-storage/udaipur-lake-palace_1cb9f22e.jpg" },
  { name: "Munnar", state: "Kerala", category: "Nature", budget: "₹7,200", tone: "from-emerald-950 via-emerald-700 to-lime-300", icon: Waves, image: "/manus-storage/munnar-owned_6f32b499.jpg" },
  { name: "Manali", state: "Himachal Pradesh", category: "Adventure", budget: "₹9,800", tone: "from-slate-950 via-blue-800 to-sky-300", icon: Map, image: "/manus-storage/manali-owned_02d41015.jpg" },
  { name: "Panaji", state: "Goa", category: "Culture", budget: "₹6,900", tone: "from-indigo-950 via-violet-700 to-fuchsia-300", icon: Waves, image: "/manus-storage/panaji-owned_98931b77.jpg" },
];

const iconByCategory: Record<string, typeof Compass> = { Heritage: Compass, Nature: Waves, Adventure: Map, Beach: Waves, Waterfall: Waves, Trekking: Map, City: Compass, Culture: Utensils, Spiritual: Compass };

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const { data: featuredData = [], isLoading: featuredLoading } = trpc.tourism.featuredDestinations.useQuery({ limit: 8 });
  const featuredPlaces = useMemo(() => {
    const source = featuredData.length ? featuredData : destinations;
    return source.map((place) => ({
      name: place.name,
      stateLabel: "stateName" in place ? place.stateName : place.state,
      category: place.category,
      budget: place.budget,
      tone: "tone" in place ? place.tone : "from-emerald-950 via-emerald-700 to-lime-300",
      icon: "icon" in place ? place.icon : iconByCategory[place.category] ?? Compass,
      image: place.image ?? "",
      slug: "slug" in place ? place.slug : place.name.toLowerCase().replaceAll(" ", "-"),
    }));
  }, [featuredData]);
  const maxFeaturedIndex = Math.max(0, featuredPlaces.length - 3);
  const visibleFeaturedPlaces = featuredPlaces.slice(Math.min(featuredIndex, maxFeaturedIndex), Math.min(featuredIndex, maxFeaturedIndex) + 3);
  const filteredStates = useMemo(
    () => states.filter((state) => state.name.toLowerCase().includes(query.toLowerCase())),
    [query],
  );

  return (
    <div className="min-h-screen bg-[#f8f6f1] text-[#18221c]">
      <header className="sticky top-0 z-30 border-b border-[#dfe5dc]/80 bg-[#f8f6f1]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link href="/" className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#183d2b] text-[#f5d28e] shadow-lg shadow-[#183d2b]/20"><Compass size={21} /></span>
            <span className="font-serif text-xl font-semibold tracking-tight">TravelBharat</span>
          </Link>
          <nav className="hidden items-center gap-8 text-sm font-medium text-[#5b6a5e] md:flex">
            <a href="#discover" className="transition-colors hover:text-[#183d2b]">Discover</a>
            <a href="#experiences" className="transition-colors hover:text-[#183d2b]">Experiences</a>
            <a href="#plan" className="transition-colors hover:text-[#183d2b]">Plan a trip</a>
          </nav>
          <div className="flex items-center gap-3">
            {isAuthenticated ? <div className="hidden items-center gap-3 sm:flex"><span className="max-w-32 truncate text-sm text-[#647267]" title={user?.name ?? "Account"}>{user?.name ?? "Account"}</span><button type="button" onClick={() => logout()} className="text-sm font-medium text-[#46604e] transition-colors hover:text-[#183d2b]" aria-label="Sign out">Sign out</button></div> : <button type="button" onClick={startLogin} className="hidden text-sm font-medium text-[#46604e] transition-colors hover:text-[#183d2b] sm:inline-flex">Sign in</button>}
            <Link href="/discover" className="rounded-full bg-[#183d2b] px-5 py-2.5 text-sm font-semibold text-[#fffdf7] transition-colors hover:bg-[#28583e]">Start exploring</Link>
            <Button aria-label={mobileOpen ? "Close menu" : "Open menu"} aria-expanded={mobileOpen} variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen((open) => !open)}>{mobileOpen ? <X size={21} /> : <Menu size={21} />}</Button>
          </div>
        </div>
        {mobileOpen && <nav className="border-t border-[#dfe5dc] bg-[#f8f6f1] px-5 py-4 md:hidden"><div className="mx-auto flex max-w-7xl flex-col gap-4 text-sm font-medium text-[#5b6a5e]"><a href="#discover" onClick={() => setMobileOpen(false)}>Discover</a><a href="#experiences" onClick={() => setMobileOpen(false)}>Experiences</a><a href="#plan" onClick={() => setMobileOpen(false)}>Plan a trip</a></div></nav>}
      </header>

      <main>
        <section className="relative overflow-hidden px-5 pb-20 pt-16 lg:px-8 lg:pb-28 lg:pt-24">
          <div className="absolute -right-24 -top-32 h-96 w-96 rounded-full bg-[#d4e7ca]/60 blur-3xl" />
          <div className="absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-[#f2d8a1]/35 blur-3xl" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.03fr_.97fr]">
            <div>
              <Badge className="mb-6 rounded-full border border-[#c9ddc2] bg-[#eaf3e5] px-4 py-2 text-[#2e6744] hover:bg-[#eaf3e5]"><Sparkles size={14} className="mr-2" /> Curated journeys across India</Badge>
              <h1 className="max-w-3xl font-serif text-5xl leading-[1.02] tracking-[-0.04em] text-[#183d2b] sm:text-6xl lg:text-7xl">Go beyond places.<br /><span className="text-[#c27935]">Find your India.</span></h1>
              <p className="mt-7 max-w-xl text-lg leading-8 text-[#647267]">Explore state by state, from quiet backwaters to living forts. Discover the stories, flavours, and landscapes that make every journey feel personal.</p>
              <div className="mt-9 flex max-w-xl items-center gap-3 rounded-2xl border border-[#d8e2d5] bg-white p-2 shadow-xl shadow-[#304a37]/10">
                <Search className="ml-3 text-[#789080]" size={20} />
                <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search a state or destination" className="border-0 bg-transparent text-base shadow-none focus-visible:ring-0" />
                <Button type="button" onClick={() => { const term = query.trim(); window.location.href = term ? `/discover?search=${encodeURIComponent(term)}` : "/discover"; }} className="rounded-xl bg-[#c27935] px-5 hover:bg-[#a85e22]">Search</Button>
              </div>
              <div className="mt-8 flex flex-wrap gap-x-7 gap-y-3 text-sm text-[#6a786c]"><span><strong className="text-[#183d2b]">36</strong> regions mapped</span><span><strong className="text-[#183d2b]">160+</strong> destinations</span><span><strong className="text-[#183d2b]">Curated</strong> itineraries</span></div>
            </div>
            <div className="relative mx-auto w-full max-w-xl">
              <Link href="/destinations/udaipur" aria-label="Explore the Udaipur Rajasthan featured journey" className="group block rounded-[2rem] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#c27935]/40"><div className="relative aspect-[.88] overflow-hidden rounded-[2rem] bg-[#183d2b] p-5 shadow-2xl shadow-[#183d2b]/20 transition-transform duration-300 group-hover:-translate-y-1">
                <img src="/manus-storage/udaipur-lake-palace_1cb9f22e.jpg" alt="Udaipur lake palace, Rajasthan featured journey" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071c12]/90 via-[#0c271a]/35 to-[#183d2b]/15" />
                <div className="relative flex h-full flex-col justify-between rounded-[1.35rem] border border-white/25 bg-gradient-to-t from-[#0c271a]/55 via-transparent to-white/10 p-7 text-white">
                  <div className="flex items-start justify-between"><span className="rounded-full bg-white/15 px-4 py-2 text-xs uppercase tracking-[.2em] backdrop-blur">The north star route</span><Map size={22} className="text-[#f5d28e]" /></div>
                  <div><p className="text-sm text-white/70">Featured journey</p><h2 className="mt-2 font-serif text-4xl">Rajasthan, in colour</h2><div className="mt-5 flex items-center gap-4 text-sm text-white/80"><span>7 days</span><span className="h-1 w-1 rounded-full bg-[#f5d28e]" /><span>Heritage & culture</span></div></div>
                </div>
              </div></Link>
              <div className="absolute -bottom-7 -left-7 hidden rounded-2xl border border-[#e6e0d3] bg-white p-4 shadow-xl sm:block"><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#fff3db] text-[#c27935]"><Compass size={19} /></span><div><p className="text-xs text-[#7b877b]">TravelBharat catalogue</p><p className="font-semibold text-[#183d2b]">Photo-first planning</p></div></div></div>
            </div>
          </div>
        </section>

        <section id="discover" className="border-y border-[#e4e8df] bg-white px-5 py-20 lg:px-8">
          <div className="mx-auto max-w-7xl"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-sm font-semibold uppercase tracking-[.18em] text-[#bd7431]">Start with a state</p><h2 className="mt-3 font-serif text-4xl tracking-tight text-[#183d2b] sm:text-5xl">Every state, a different rhythm.</h2></div><Link href="/states" className="inline-flex w-fit items-center text-sm font-semibold text-[#2e6744]">View all states <ArrowRight size={16} className="ml-2" /></Link></div><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{filteredStates.map((state) => <Link key={state.name} href={`/states/${state.name.toLowerCase().replaceAll(" ", "-")}`}><Card className="group overflow-hidden rounded-3xl border-0 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"><CardContent className={`relative flex h-56 flex-col justify-end overflow-hidden bg-gradient-to-br ${state.tone} p-6 text-white`}><img src={state.image} alt={`${state.name} travel destination`} className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105" /><div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-black/5" /><div className="absolute right-5 top-5 z-10 flex h-12 w-12 items-center justify-center rounded-full border border-white/30 bg-white/15 font-serif text-lg backdrop-blur">{state.initials}</div><div className="relative z-10"><p className="text-sm text-white/85">{state.count}</p><h3 className="mt-1 font-serif text-2xl">{state.name}</h3><span className="mt-3 inline-flex items-center text-sm text-white/90">Explore state <ArrowRight size={14} className="ml-2 transition-transform group-hover:translate-x-1" /></span></div></CardContent></Card></Link>)}</div>{filteredStates.length === 0 && <p className="mt-8 text-[#6a786c]">No states found. Try another search.</p>}</div>
        </section>

        <section id="experiences" className="px-5 py-20 lg:px-8"><div className="mx-auto max-w-7xl"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div className="max-w-2xl"><p className="text-sm font-semibold uppercase tracking-[.18em] text-[#bd7431]">Featured destinations</p><h2 className="mt-3 font-serif text-4xl tracking-tight text-[#183d2b] sm:text-5xl">Places worth taking the long way to.</h2><p className="mt-4 text-base leading-7 text-[#69776c]">Photo-first picks from across India, selected from the live destination catalogue.</p></div><div className="flex items-center gap-2" aria-label="Featured destinations carousel controls"><Button type="button" variant="outline" size="icon" onClick={() => setFeaturedIndex((index) => Math.max(0, index - 1))} disabled={featuredIndex === 0 || featuredLoading} aria-label="Previous featured destinations"><ArrowRight className="rotate-180" size={17} /></Button><Button type="button" variant="outline" size="icon" onClick={() => setFeaturedIndex((index) => Math.min(maxFeaturedIndex, index + 1))} disabled={featuredIndex >= maxFeaturedIndex || featuredLoading} aria-label="Next featured destinations"><ArrowRight size={17} /></Button></div></div>{featuredLoading && <div className="mt-10 rounded-3xl border border-[#e2e9df] bg-white p-10 text-center text-[#69776c]">Loading featured destinations…</div>}{!featuredLoading && <div className="mt-10 grid gap-5 md:grid-cols-3">{visibleFeaturedPlaces.map(({ name, stateLabel, category, budget, tone, icon: Icon, image, slug }) => <Card key={slug ?? name} className="overflow-hidden rounded-3xl border-[#e2e9df] bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"><div className={`relative flex h-44 items-end overflow-hidden bg-gradient-to-br ${tone ?? "from-emerald-950 via-emerald-700 to-lime-300"} p-5`}><img src={image} alt={`${name}, ${stateLabel} travel destination`} className="absolute inset-0 h-full w-full object-cover" loading="eager" /><div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" /><div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 text-white backdrop-blur"><Icon size={23} /></div></div><CardContent className="p-6"><div className="flex items-center justify-between"><Badge variant="secondary" className="bg-[#edf4e9] text-[#39704c]">{category}</Badge><span className="text-right text-xs leading-4 text-[#768278]">Price not published</span></div><h3 className="mt-4 font-serif text-2xl text-[#183d2b]">{name}</h3><p className="mt-1 text-sm text-[#78857b]">{stateLabel}</p><Link href={`/destinations/${slug}`} className="mt-5 inline-flex items-center text-sm font-semibold text-[#2e6744]">View destination <ArrowRight size={15} className="ml-2" /></Link></CardContent></Card>)}</div>}</div></section>

        <section id="plan" className="rounded-[36px] bg-[#183d2b] px-5 py-20 text-white lg:px-8" style={{ paddingTop: "23px" }}><div className="mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[1fr_.8fr]"><div><Badge className="rounded-[36px] border-white/20 bg-white/10 text-[#f5d28e] hover:bg-white/10">Your next chapter</Badge><h2 className="mt-5 max-w-2xl font-serif text-4xl leading-tight sm:text-5xl">A better trip starts before you pack.</h2><p className="mt-5 max-w-xl text-lg leading-8 text-white/65">Save the places that call to you, build a day-by-day itinerary, and keep every detail of your journey in one thoughtful space.</p><Link href="/plan" className="mt-8 inline-flex items-center rounded-full bg-[#f5d28e] px-6 py-3 font-semibold text-[#183d2b] transition-colors hover:bg-[#ffe1a7]">Create your itinerary <ArrowRight size={16} className="ml-2" /></Link></div><div className="grid grid-cols-2 gap-3"><div className="rounded-[36px] border border-white/10 bg-white/10 p-6"><Map className="text-[#f5d28e]" size={24} /><p className="mt-14 font-serif text-2xl">Live maps</p><p className="mt-2 text-sm text-white/55">Find your way with confidence.</p></div><div className="mt-8 rounded-[36px] border border-white/10 bg-[#c27935] p-6"><Utensils className="text-white" size={24} /><p className="mt-14 font-serif text-2xl">Local flavour</p><p className="mt-2 text-sm text-white/75">Go where the good stories are.</p></div></div></div></section>
      </main>
      <footer className="bg-[#102b1e] px-5 py-8 text-sm text-white/55 lg:px-8"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-3 sm:flex-row"><p>© 2026 TravelBharat. Built for meaningful journeys.</p><p>Explore thoughtfully. Travel lightly.</p></div></footer>
    </div>
  );
}
