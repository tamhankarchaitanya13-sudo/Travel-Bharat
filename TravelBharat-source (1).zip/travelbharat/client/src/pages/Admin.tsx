import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Check, Eye, ShieldAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

export default function Admin() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [authTimedOut, setAuthTimedOut] = useState(false);
  const queue = trpc.admin.moderationQueue.useQuery(undefined, { enabled: user?.role === "admin" });
  const updateStatus = trpc.admin.updateDestinationStatus.useMutation({
    onSuccess: () => queue.refetch(),
  });

  useEffect(() => {
    if (!loading && user && user.role !== "admin") navigate("/");
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!loading) return;
    const timeout = window.setTimeout(() => setAuthTimedOut(true), 5000);
    return () => window.clearTimeout(timeout);
  }, [loading]);

  if (loading && !authTimedOut) {
    return <main className="flex min-h-screen items-center justify-center bg-[#f8f6f1] text-[#647267]">Checking access…</main>;
  }

  if (!user) {
    return <main className="flex min-h-screen items-center justify-center bg-[#f8f6f1] px-5 text-center"><div className="max-w-md"><ShieldAlert className="mx-auto text-[#bd7431]" size={32} /><h1 className="mt-4 font-serif text-4xl text-[#183d2b]">Admin sign-in required</h1><p className="mt-3 leading-7 text-[#647267]">Sign in with an authorized TravelBharat administrator account to review destination content.</p><Button onClick={() => startLogin()} className="mt-6 rounded-full bg-[#183d2b] text-white hover:bg-[#28583e]">Sign in</Button><Link href="/" className="mt-4 block text-sm font-semibold text-[#2e6744]">Return home</Link></div></main>;
  }

  if (user.role !== "admin") return null;

  return (
    <main className="min-h-screen bg-[#f8f6f1] px-5 py-12 text-[#18221c] lg:px-8">
      <div className="mx-auto max-w-6xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#2e6744]"><ArrowLeft size={16} /> Back to TravelBharat</Link>
        <div className="mt-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div><p className="text-sm font-semibold uppercase tracking-[.18em] text-[#bd7431]">Admin workspace</p><h1 className="mt-3 font-serif text-5xl text-[#183d2b]">Moderation queue</h1><p className="mt-4 max-w-2xl text-lg leading-8 text-[#647267]">Review destinations before changing their public visibility. This queue only exposes records marked draft or needs review.</p></div>
          <Badge className="w-fit bg-[#edf4e9] text-[#39704c]"><ShieldAlert size={14} className="mr-2" /> Admin-only</Badge>
        </div>

        {queue.isLoading && <div className="mt-10 rounded-3xl border border-[#e2e9df] bg-white p-10 text-center text-[#647267]">Loading moderation queue…</div>}
        {queue.isError && <div className="mt-10 rounded-3xl border border-red-200 bg-red-50 p-6 text-red-800">The moderation queue could not be loaded. Try again shortly.</div>}
        {!queue.isLoading && !queue.isError && queue.data?.length === 0 && <div className="mt-10 rounded-3xl border border-[#e2e9df] bg-white p-10 text-center"><Check className="mx-auto text-[#39704c]" size={28} /><p className="mt-3 font-serif text-2xl text-[#183d2b]">Queue is clear</p><p className="mt-2 text-[#647267]">No draft or needs-review destinations are waiting.</p></div>}
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {queue.data?.map(({ destination, stateName }) => (
            <Card key={destination.id} className="overflow-hidden rounded-3xl border-[#e2e9df] bg-white shadow-sm">
              {destination.image && <img src={destination.image} alt={`${destination.name} moderation preview`} className="h-48 w-full object-cover" />}
              <CardHeader><div className="flex items-start justify-between gap-4"><div><CardTitle className="font-serif text-2xl text-[#183d2b]">{destination.name}</CardTitle><p className="mt-1 text-sm text-[#768278]">{stateName ?? "India"} · {destination.category}</p></div><Badge variant="outline">{destination.moderationStatus.replace("_", " ")}</Badge></div></CardHeader>
              <CardContent><p className="line-clamp-3 text-sm leading-6 text-[#647267]">{destination.description}</p><div className="mt-5 flex flex-wrap gap-2"><Link href={`/destinations/${destination.slug}`}><Button variant="outline" className="rounded-full"><Eye size={15} className="mr-2" /> Preview</Button></Link><Button onClick={() => updateStatus.mutate({ destinationId: destination.id, moderationStatus: "published" })} disabled={updateStatus.isPending} className="rounded-full bg-[#183d2b] text-white hover:bg-[#28583e]">Publish</Button><Button onClick={() => updateStatus.mutate({ destinationId: destination.id, moderationStatus: "needs_review" })} disabled={updateStatus.isPending} variant="outline" className="rounded-full">Needs review</Button></div></CardContent>
            </Card>
          ))}
        </div>
      </div>
    </main>
  );
}

