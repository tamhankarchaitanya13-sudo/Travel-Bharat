import { useRoute, Link } from "wouter";
import { ArrowLeft, BusFront, CalendarDays, Check, Clock3, Compass, Hotel, Images, Landmark, Mail, MapPin, Phone, Ticket, Wallet } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import PublicHeader from "@/components/PublicHeader";

const toneByCategory: Record<string, string> = {
  Heritage: "from-orange-950 via-orange-700 to-amber-300",
  Nature: "from-emerald-950 via-emerald-700 to-lime-300",
  Adventure: "from-slate-950 via-blue-800 to-sky-300",
  Culture: "from-indigo-950 via-violet-700 to-fuchsia-300",
  Spiritual: "from-red-950 via-rose-700 to-orange-300",
};

function DetailFact({ icon: Icon, label, value }: { icon: typeof Wallet; label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div className="flex gap-3">
      <Icon size={19} className="mt-0.5 shrink-0 text-[#2e6744]" aria-hidden="true" />
      <div>
        <p className="text-xs text-[#879187]">{label}</p>
        <p className="mt-1 font-semibold text-[#183d2b]">{value}</p>
      </div>
    </div>
  );
}

export default function DestinationDetail() {
  const [, params] = useRoute("/destinations/:id");
  const slug = params?.id ?? "";
  const { data: destination, isLoading, error } = trpc.tourism.destinationBySlug.useQuery({ slug }, { enabled: Boolean(slug) });
  const { data: gallery = [], isLoading: galleryLoading } = trpc.tourism.destinationGallery.useQuery(
    { destinationId: destination?.id ?? 0 },
    { enabled: Boolean(destination?.id) },
  );
  const { data: hotels = [], isLoading: hotelsLoading } = trpc.trips.hotels.useQuery({ destinationId: destination?.id ?? 0 }, { enabled: Boolean(destination?.id) });
  const { data: transportation = [], isLoading: transportationLoading } = trpc.trips.transportation.useQuery({ destinationId: destination?.id ?? 0 }, { enabled: Boolean(destination?.id) });
  const highlights = destination?.highlights?.split("|").filter(Boolean) ?? [];
  const nearbyAttractions = destination?.nearbyAttractions?.split("|").filter(Boolean) ?? [];

  if (isLoading) return <div className="min-h-screen bg-[#f8f6f1] p-8 text-[#647267]">Loading destination details…</div>;
  if (error || !destination) {
    return (
      <div className="min-h-screen bg-[#f8f6f1] p-8 text-[#183d2b]">
        <Link href="/discover" className="inline-flex items-center gap-2 font-semibold"><ArrowLeft size={16} /> Return to discoveries</Link>
        <h1 className="mt-12 font-serif text-4xl">Destination not found</h1>
        <p className="mt-3 text-[#647267]">Try choosing another place from the discovery catalogue.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8f6f1] text-[#18221c]">
      <PublicHeader backHref="/discover" backLabel="Back to discover" />
      <main className="mx-auto max-w-7xl px-5 py-10 lg:px-8">
        <section className={`relative flex min-h-[360px] items-end overflow-hidden rounded-[2rem] bg-gradient-to-br ${toneByCategory[destination.category] ?? "from-slate-800 via-teal-700 to-cyan-300"} p-8 text-white shadow-xl sm:p-12`} aria-labelledby="destination-title">
          {destination.image && <img src={destination.image} alt={`${destination.name} destination`} className="absolute inset-0 z-10 h-full w-full object-cover" loading="eager" />}
          <div className="absolute inset-0 z-20 bg-gradient-to-t from-black/75 via-black/20 to-black/5" />
          <div className="relative z-30 max-w-3xl">
            <Badge className="border-white/20 bg-white/15 text-white backdrop-blur hover:bg-white/15">{destination.category}</Badge>
            <p className="mt-5 text-sm text-white/75">{destination.city ? `${destination.city}, ` : ""}{destination.stateName}</p>
            <h1 id="destination-title" className="mt-1 font-serif text-5xl sm:text-6xl">{destination.name}</h1>
            <p className="mt-4 max-w-2xl text-lg leading-8 text-white/85">{destination.description}</p>
          </div>
        </section>

        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
          <section>
            <div className="flex items-center gap-3"><Compass className="text-[#bd7431]" size={22} /><h2 className="font-serif text-3xl text-[#183d2b]">Plan your visit</h2></div>
            <p className="mt-3 leading-7 text-[#647267]">Explore the practical details, context, and nearby places before shaping your journey.</p>

            {highlights.length > 0 && <div className="mt-7 grid gap-3 sm:grid-cols-3">{highlights.map((highlight) => <div key={highlight} className="flex items-start gap-3 rounded-2xl border border-[#dfe5dc] bg-white p-4"><Check size={17} className="mt-0.5 text-[#bd7431]" aria-hidden="true" /><span className="text-sm font-medium text-[#36533f]">{highlight}</span></div>)}</div>}

            <div className="mt-8 grid gap-6 md:grid-cols-2">
              <article className="rounded-3xl border border-[#dfe5dc] bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3"><Landmark size={20} className="text-[#2e6744]" /><h2 className="font-serif text-2xl text-[#183d2b]">About this place</h2></div>
                <p className="mt-4 leading-7 text-[#647267]">{destination.historicalSignificance ?? "Historical and cultural information for this destination will be curated by the TravelBharat team."}</p>
              </article>
              <article className="rounded-3xl border border-[#dfe5dc] bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3"><MapPin size={20} className="text-[#2e6744]" /><h2 className="font-serif text-2xl text-[#183d2b]">Nearby attractions</h2></div>
                {nearbyAttractions.length > 0 ? <ul className="mt-4 space-y-3 text-[#647267]">{nearbyAttractions.map((place) => <li key={place} className="flex gap-2"><span className="text-[#bd7431]">•</span>{place}</li>)}</ul> : <p className="mt-4 leading-7 text-[#647267]">Nearby attractions will be added by the administrator.</p>}
              </article>
            </div>

            <section className="mt-8 grid gap-6 md:grid-cols-2" aria-label="Travel services">
              <article className="rounded-3xl border border-[#dfe5dc] bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3"><Hotel size={20} className="text-[#2e6744]" /><h2 className="font-serif text-2xl text-[#183d2b]">Hotels</h2></div>
                {hotelsLoading ? <p className="mt-4 text-sm text-[#647267]">Loading verified hotel contacts…</p> : hotels.length ? <div className="mt-4 space-y-4">{hotels.map((hotel) => <div key={hotel.id} className="overflow-hidden rounded-2xl border border-[#e5ebe1] bg-[#f8faf6]">{hotel.image ? <img src={hotel.image} alt={`${hotel.name} hotel`} className="h-28 w-full object-cover" loading="lazy" /> : <div className="flex h-20 items-center justify-center bg-[#eaf3e5] text-xs text-[#78857b]">Hotel photo pending</div>}<div className="p-4"><p className="font-semibold text-[#183d2b]">{hotel.name}</p>{hotel.priceRange && <p className="mt-1 text-sm text-[#647267]">{hotel.priceRange}</p>}<div className="mt-2 flex flex-wrap gap-x-3 gap-y-1">{hotel.contactPhone && <a href={`tel:${hotel.contactPhone}`} className="flex items-center gap-2 text-sm font-medium text-[#2e6744]"><Phone size={14} />{hotel.contactPhone}</a>}{hotel.contactEmail && <a href={`mailto:${hotel.contactEmail}`} className="flex items-center gap-2 text-sm font-medium text-[#2e6744]"><Mail size={14} />Email</a>}</div>{hotel.bookingUrl && <a href={hotel.bookingUrl} target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm font-semibold text-[#2e6744]">Open booking link</a>}</div></div>)}</div> : <p className="mt-4 text-sm leading-6 text-[#647267]">No verified hotel record is published for this destination yet. TravelBharat will not invent contact or price details.</p>}
              </article>
              <article className="rounded-3xl border border-[#dfe5dc] bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3"><BusFront size={20} className="text-[#315f9b]" /><h2 className="font-serif text-2xl text-[#183d2b]">Transportation</h2></div>
                {transportationLoading ? <p className="mt-4 text-sm text-[#647267]">Loading published transport options…</p> : transportation.length ? <div className="mt-4 space-y-4">{transportation.map((option) => <div key={option.id} className="rounded-2xl border border-[#d6e0ef] bg-[#f7faff] p-4"><div className="flex items-start justify-between gap-3"><p className="font-semibold capitalize text-[#183d2b]">{option.mode.replace("_", " ")}</p><span className="text-xs font-semibold uppercase tracking-[.08em] text-[#66717a]">{option.availability}</span></div><p className="mt-1 text-sm text-[#36533f]">{option.provider}</p>{option.route && <p className="mt-2 text-sm text-[#647267]">{option.route}</p>}{(option.departureTime || option.arrivalTime) && <p className="mt-2 text-xs text-[#647267]">{option.departureTime ? `Departs ${option.departureTime}` : "Departure time not published"}{option.arrivalTime ? ` · Arrives ${option.arrivalTime}` : " · Arrival time not published"}</p>}{option.fare ? <p className="mt-2 font-semibold text-[#183d2b]">{option.currency ?? "INR"} {option.fare}</p> : <p className="mt-2 text-xs text-[#78857b]">Fare not published.</p>}{option.priceSource && <p className="mt-2 text-[11px] leading-4 text-[#78857b]">Source: {option.priceSource}{option.priceUpdatedAt ? ` · Updated ${option.priceUpdatedAt}` : ""}</p>}</div>)}</div> : <p className="mt-4 text-sm leading-6 text-[#647267]">No published transport option is available yet. Live fares and schedules will appear only after a verified source is connected.</p>}
              </article>
            </section>

            <div className="mt-8 flex flex-wrap gap-3"><Link href={`/plan?destination=${destination.id}`}><Button className="rounded-full bg-[#183d2b] text-white hover:bg-[#28583e]">Plan this trip</Button></Link><Link href="/discover"><Button variant="outline" className="rounded-full border-[#cbd8c8] text-[#36533f]">Browse more places</Button></Link></div>
          </section>

          <aside className="rounded-3xl border border-[#dfe5dc] bg-white p-6 shadow-sm"><p className="text-sm font-semibold uppercase tracking-[.16em] text-[#bd7431]">Quick facts</p><div className="mt-6 space-y-5"><DetailFact icon={Wallet} label="Estimated trip budget" value={destination.budget ? `From ${destination.budget}` : null} /><DetailFact icon={CalendarDays} label="Best season" value={destination.bestSeason ?? "Plan around local conditions"} /><DetailFact icon={Ticket} label="Entry fee" value={destination.entryFee ?? "Check locally before visiting"} /><DetailFact icon={Clock3} label="Opening hours" value={destination.openingHours ?? "Check official local timings"} /><DetailFact icon={MapPin} label="Region" value={destination.city ? `${destination.city}, ${destination.stateName}` : destination.stateName} /></div></aside>
        </div>

        <section className="mt-10 rounded-3xl border border-[#dfe5dc] bg-white p-5 shadow-sm" aria-labelledby="gallery-heading">
          <div className="flex items-center gap-3"><Images className="text-[#bd7431]" size={22} /><div><h2 id="gallery-heading" className="font-serif text-3xl text-[#183d2b]">Destination gallery</h2><p className="mt-1 text-sm text-[#647267]">A visual preview of {destination.name} and its surroundings.</p></div></div>
          {galleryLoading ? <div className="mt-5 flex h-48 items-center justify-center rounded-2xl bg-[#f3f6f0] text-sm text-[#647267]">Loading gallery…</div> : gallery.length > 0 ? <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{gallery.map((image) => <figure key={image.id} className="overflow-hidden rounded-2xl bg-[#eef2eb]"><img src={image.imageUrl} alt={image.altText} className="h-56 w-full object-cover transition duration-300 hover:scale-[1.02]" loading="lazy" /><figcaption className="px-4 py-3 text-sm text-[#647267]">{image.altText}</figcaption></figure>)}</div> : <div className="mt-5 flex min-h-48 items-center justify-center rounded-2xl border border-dashed border-[#cbd8c8] bg-[#f3f6f0] px-6 text-center text-sm text-[#647267]">The gallery is being curated. Check back soon for destination photographs.</div>}
        </section>

        <section className="mt-10 overflow-hidden rounded-3xl border border-[#dfe5dc] bg-white p-3 shadow-sm"><div className="px-3 pb-3 pt-2"><p className="text-sm font-semibold uppercase tracking-[.16em] text-[#bd7431]">Find it on the map</p><p className="mt-2 text-sm text-[#647267]">Use the live map to orient yourself around {destination.name}.</p></div>{destination.latitude && destination.longitude ? <MapView className="h-[360px] rounded-2xl" initialCenter={{ lat: Number(destination.latitude), lng: Number(destination.longitude) }} initialZoom={11} onMapReady={(map) => { new google.maps.marker.AdvancedMarkerElement({ map, position: { lat: Number(destination.latitude), lng: Number(destination.longitude) }, title: destination.name }); }} /> : <div className="flex h-48 items-center justify-center rounded-2xl bg-[#f3f6f0] text-sm text-[#647267]">Map coordinates will be added for this destination soon.</div>}</section>
      </main>
    </div>
  );
}
