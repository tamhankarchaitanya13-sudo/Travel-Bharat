import { beforeEach, describe, expect, it, vi } from "vitest";
import { loadMapScript } from "./Map";

describe("loadMapScript", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    (globalThis as Record<string, unknown>).window = {};
  });

  it("appends only one script when called repeatedly while loading", () => {
    const listeners = new Map<string, () => void>();
    const script = {
      dataset: {} as Record<string, string>,
      addEventListener: vi.fn((event: string, handler: () => void) => {
        listeners.set(event, handler);
      }),
    };
    const appendChild = vi.fn();
    const documentMock = {
      querySelector: vi.fn(() => null),
      createElement: vi.fn(() => script),
      head: { appendChild },
    };

    (globalThis as Record<string, unknown>).document = documentMock;

    const firstRequest = loadMapScript();
    const secondRequest = loadMapScript();

    expect(secondRequest).toBe(firstRequest);
    expect(documentMock.createElement).toHaveBeenCalledTimes(1);
    expect(appendChild).toHaveBeenCalledTimes(1);
    expect(script.dataset.travelbharatGoogleMaps).toBe("true");
    expect(listeners.has("load")).toBe(true);
  });
});
