import { Compass } from "lucide-react";
import { Link } from "wouter";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function PublicHeader({ backHref = "/", backLabel = "Back home" }: { backHref?: string; backLabel?: string }) {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <header className="border-b border-[#dfe5dc] bg-[#f8f6f1]">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-8">
        <Link href="/" className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#183d2b] text-[#f5d28e]"><Compass size={21} /></span>
          <span className="font-serif text-xl font-semibold">TravelBharat</span>
        </Link>
        <div className="flex items-center gap-3 sm:gap-5">
          {isAuthenticated ? <div className="flex items-center gap-2 sm:gap-3"><span className="hidden max-w-32 truncate text-sm text-[#647267] sm:inline" title={user?.name ?? "Account"}>{user?.name ?? "Account"}</span><button type="button" onClick={() => logout()} className="whitespace-nowrap text-sm font-semibold text-[#46604e] hover:text-[#183d2b]" aria-label="Sign out">Sign out</button></div> : <button type="button" onClick={startLogin} className="text-sm font-semibold text-[#46604e] hover:text-[#183d2b]">Sign in</button>}
          <Link href={backHref} className="whitespace-nowrap text-sm font-semibold text-[#46604e]">{backLabel}</Link>
        </div>
      </div>
    </header>
  );
}
