export type State = { name: string; count: string; tone: string; initials: string; description: string; image: string };
export type Destination = { id: string; name: string; state: string; category: string; budget: string; description: string; tone: string; highlights: string[]; image: string };

export const states: State[] = [
  { name: "Rajasthan", count: "24 destinations", tone: "from-amber-700 via-orange-500 to-yellow-300", initials: "RJ", description: "Living forts, desert skies, and stories carried through generations.", image: "/manus-storage/udaipur-lake-palace_1cb9f22e.jpg" },
  { name: "Kerala", count: "18 destinations", tone: "from-emerald-900 via-teal-600 to-lime-300", initials: "KL", description: "Backwaters, spice gardens, and a slower way of seeing the world.", image: "/manus-storage/munnar-owned_6f32b499.jpg" },
  { name: "Himachal Pradesh", count: "16 destinations", tone: "from-slate-900 via-blue-700 to-cyan-300", initials: "HP", description: "Mountain trails, cedar forests, and high-altitude quiet.", image: "/manus-storage/manali-owned_02d41015.jpg" },
  { name: "Goa", count: "12 destinations", tone: "from-indigo-950 via-violet-600 to-fuchsia-300", initials: "GA", description: "Coastal light, local flavours, and colourful neighbourhoods.", image: "/manus-storage/panaji-owned_98931b77.jpg" },
];

export const destinations: Destination[] = [
  { id: "udaipur", name: "Udaipur", state: "Rajasthan", category: "Heritage", budget: "₹8,500", description: "Lakes, palaces, and slow evenings in the city of romance.", tone: "from-orange-950 via-orange-700 to-amber-300", highlights: ["City Palace", "Lake Pichola", "Bagore Ki Haveli"], image: "/manus-storage/udaipur-lake-palace_1cb9f22e.jpg" },
  { id: "munnar", name: "Munnar", state: "Kerala", category: "Nature", budget: "₹7,200", description: "Tea gardens, misty hills, and the green quiet of the Western Ghats.", tone: "from-emerald-950 via-emerald-700 to-lime-300", highlights: ["Tea Museum", "Eravikulam National Park", "Mattupetty Dam"], image: "/manus-storage/munnar-owned_6f32b499.jpg" },
  { id: "manali", name: "Manali", state: "Himachal Pradesh", category: "Adventure", budget: "₹9,800", description: "Mountain air, riverside trails, and a gateway to the high Himalayas.", tone: "from-slate-950 via-blue-800 to-sky-300", highlights: ["Solang Valley", "Old Manali", "Hadimba Temple"], image: "/manus-storage/manali-owned_02d41015.jpg" },
  { id: "panaji", name: "Panaji", state: "Goa", category: "Culture", budget: "₹6,900", description: "Portuguese lanes, river sunsets, and a softer side of Goa.", tone: "from-indigo-950 via-violet-700 to-fuchsia-300", highlights: ["Fontainhas", "Mandovi River", "Our Lady of the Immaculate Conception"], image: "/manus-storage/panaji-owned_98931b77.jpg" },
  { id: "varanasi", name: "Varanasi", state: "Uttar Pradesh", category: "Spiritual", budget: "₹5,400", description: "Ancient ghats, living traditions, and a city shaped by the Ganges.", tone: "from-red-950 via-rose-700 to-orange-300", highlights: ["Dashashwamedh Ghat", "Sarnath", "Ganga Aarti"], image: "/manus-storage/varanasi-owned_0a36d27c.jpg" },
  { id: "darjeeling", name: "Darjeeling", state: "West Bengal", category: "Nature", budget: "₹8,100", description: "Toy trains, tea estates, and sunrise views over Kanchenjunga.", tone: "from-teal-950 via-cyan-700 to-emerald-300", highlights: ["Tiger Hill", "Darjeeling Himalayan Railway", "Batasia Loop"], image: "/manus-storage/darjeeling-owned_4e6cfb9d.jpg" },
];
