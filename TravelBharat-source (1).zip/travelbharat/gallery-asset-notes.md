# Gallery asset notes

Image search returned Wikimedia Commons candidates suitable for destination-gallery review:

| Candidate | Title | Local path | Source note |
|---|---|---|---|
| 1 | Category:Tourism in India - Wikimedia Commons | `/home/ubuntu/upload/search_images/QlNp4cgI9TmW.jpg` | Wikimedia Commons category result; verify individual file licensing before use |
| 2 | File:Darjeeling.jpg - Wikimedia Commons | `/home/ubuntu/upload/search_images/DwIsjHNYiHkS.jpg` | Wikimedia Commons candidate for Darjeeling; verify individual file licensing before use |
| 3 | India - Wikimedia Commons | `/home/ubuntu/upload/search_images/xH9VFxG2lYZS.jpg` | Wikimedia Commons image; verify individual file licensing before use |
| 4 | Best Tourist Destinations in India - India Tourism | `/home/ubuntu/upload/search_images/lvSCjNpnAhQh.webp` | India Tourism result; licensing/permission must be verified before deployment |

No direct source URLs were returned by the image search result. Do not treat the downloaded candidates as production assets until their individual source pages and licenses are confirmed. The application may use gradients or existing stored image fields as fallback content while licensing is verified.
