# TravelBharat Nationwide Directory Expansion

## Scope

TravelBharat is being expanded from a curated destination catalogue into a state-and-union-territory directory. The current database contains 36 represented Indian regions, including states and union territories, and every represented region currently has at least one destination record. The directory is intentionally being expanded in batches so that each destination can retain its own photo, coordinates, category, and practical travel metadata rather than receiving recycled records.

## Data contract for every destination

Each imported destination must have a unique name and slug, a valid region relationship, a category, a human-readable description, city or locality context when known, latitude and longitude, a primary image, and provenance notes for the image. Practical fields such as entry fee and opening hours must use an explicit unavailable state when verified data is not available; estimated values must not be presented as live prices.

## Region import workflow

A region batch should be prepared as a structured data file containing one row per destination. Before insertion, the importer must validate unique slugs, region existence, non-empty descriptions, coordinate formatting, primary-image presence, and destination-specific image mapping. The database migration or insert operation should be reviewed before execution. After insertion, the batch must be checked through the public state directory, search results, and representative destination detail pages.

## Current UI support

The public state directory now reads backend-computed destination counts and missing-primary-image counts through `tourism.stateDirectory`. Each region card reports its directory count and, when relevant, the number of records still awaiting a primary photo. The existing state detail route continues to display all destinations returned for the selected region.

## Next staged batches

Goa is the first high-density validation batch and should be expanded to at least 50 distinct visiting spots with verified coordinates and destination-specific images. After the Goa batch is verified, the same import contract can be applied to Maharashtra, Rajasthan, Kerala, Karnataka, Himachal Pradesh, Tamil Nadu, Gujarat, Uttar Pradesh, West Bengal, and the remaining regions in staged groups. A region is not considered complete merely because it has a state record; completeness requires the agreed destination coverage target and image/location verification.

## Data integrity rules

TravelBharat must not fabricate hotel contacts, agent contacts, ratings, testimonials, or live prices. User-supplied hotel and agent data can be imported after validation. Generated or licensed destination images must remain mapped to the correct location, and a single image should not be assigned to unrelated destination names.

## Starter-batch research sources

The official [Incredible India destination index](https://www.incredibleindia.gov.in/en/destinations) organizes destination discovery across Indian states and union territories and exposes region groupings including North, North East, East, Central, West, and South. It names examples such as Lucknow, Kolkata, Jaipur, Chennai, Delhi, Hyderabad, Mumbai, Ahmedabad, Bengaluru, Pune, Varanasi, Dwarka, Hampi, Kavaratti, Sri Vijaya Puram, Srinagar, Kedarnath, Gangtok, Amritsar, and Ayodhya. It also identifies categories such as wildlife, heritage, spiritual, adventure, nature, recreation, and beaches.

The official [Incredible India Karnataka page](https://www.incredibleindia.gov.in/en/karnataka) provides a model regional inventory and names Hampi, Pattadakal, Badami, Gokarna, Bagalkote, Belagavi, Mangaluru, Vijayapura, Bengaluru, Mysuru, Bidar, and Kalaburagi, along with attractions including Lotus Mahal, Virupaksha Temple, Elephant Stables, and Lalith Mahal Palace.

The [Ministry of Tourism website](https://tourism.gov.in/) is the national policy and tourism reference point. It links to Incredible India, state tourism links, NIDHI, and other official programmes. These sources support destination-name discovery and regional taxonomy; individual coordinates, fees, timings, and image reuse rights still require destination-level verification before publication.

A structured-data search found third-party India tourism datasets on Kaggle and Mendeley, plus the Government of India data.gov.in tourism group. These sources may accelerate research, but they are not automatically cleared for production use: any dataset must be checked for license, provenance, field quality, and destination-level coordinate accuracy before import. The current starter-batch workflow therefore continues to prioritize official Incredible India and state tourism sources for names and factual references, with explicit pending states where coordinates or image rights are unresolved.
