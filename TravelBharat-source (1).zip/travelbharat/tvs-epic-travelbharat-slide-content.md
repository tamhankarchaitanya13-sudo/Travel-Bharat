# TravelBharat — TVS Credit E.P.I.C. 8.0 Case Study Deck

## Visual direction
Use a premium editorial travel aesthetic: deep forest green, warm ivory, turmeric orange, and muted sky blue. Pair large destination photography with concise product language. Use subtle progressive reveals: hero title first, then the problem statistic or friction point, then the product response. Keep transitions fast and intentional; use fade-through for evidence slides and horizontal movement for the prototype journey. Use the provided Unstop screenshots only on the challenge-context slide, not as the visual identity of TravelBharat.

## Slide 1 — TravelBharat
### India is not one destination. It is 36 regions and thousands of reasons to go.
TravelBharat is a photo-first tourism discovery and trip-planning platform that turns scattered travel information into one confident journey.

**Tagline:** Discover. Plan. Move.

**Visual:** Full-bleed Udaipur hero from the current homepage, with a small product label: “A working proof of concept.”

**Speaker cue:** “We are not building another list of tourist places. We are building the decision layer between curiosity and a completed trip.”

## Slide 2 — The challenge context
### A real-world technology problem, not just a travel website
The TVS Credit E.P.I.C. 8.0 Round 2 asks teams to propose a solution to a real-world problem and present a framework or proof of concept through a PPT, with prototype screens where required.[1]

**Problem statement:** Travel planning in India is fragmented. People discover places in one app, verify practical details somewhere else, message hotels or agents separately, and still lack a trustworthy, personal plan.

**Visual:** Cropped challenge screenshots showing the “Round 2: Case Study Challenge” requirement and the E.P.I.C. 8.0 identity.

**Speaker cue:** “Our response is a working prototype, not a concept poster.”

## Slide 3 — The user tension
### Inspiration is abundant. Confidence is scarce.
A traveler needs four answers before committing: Is this place right for me? Where exactly is it? What will I need on arrival? Can I turn it into a realistic plan?

| Today | TravelBharat response |
|---|---|
| Generic lists hide small places | State and region discovery |
| Repeated or missing imagery creates doubt | Photo-first, destination-specific mapping |
| Planning is split across tools | Authenticated itinerary studio |
| Local help is hard to find | Structured hotel and agent contacts |

**Visual:** A four-part friction-to-confidence path with a thin orange route line.

## Slide 4 — The product promise
### One India-wide discovery layer, one private trip studio
TravelBharat brings together:

1. **Explore:** Search by destination, state, union territory, category, or mood.
2. **Understand:** Open a destination detail page with imagery, location, practical information, and maps.
3. **Plan:** Create an authenticated itinerary and add day-by-day stops.
4. **Connect:** Surface destination-linked hotels and published travel-agent contacts when verified data exists.
5. **Act:** Submit a sandbox booking request without pretending to process a live payment.

**Visual:** Five connected product modules around a central “My journey” node.

## Slide 5 — Prototype walkthrough
### From “Where should I go?” to “My trip is ready.”
**Step 1:** Search “Goa” from the homepage.

**Step 2:** Discover state-aware results with destination cards and category filters.

**Step 3:** Open a place to review its hero image, location, gallery, practical details, and map context.

**Step 4:** Select “Plan a trip,” create a private itinerary, and add destinations by day.

**Step 5:** Review linked hotels and verified agent contacts, then submit a sandbox booking request.

**Visual:** Use the captured homepage, Discover, and Plan Trip screens as a three-panel storyboard.

## Slide 6 — What is implemented today
### Proof of concept: the core loop is live
| Capability | Current state |
|---|---|
| React full-stack application | Implemented |
| Database-backed states and destinations | Implemented; 36 represented regions |
| Photo-first homepage, Discover, state, and detail pages | Implemented |
| State-name and destination search | Implemented |
| Authenticated itineraries and trip stops | Implemented |
| Hotel and agent data contracts | Implemented; only verified records are shown |
| Sandbox booking request flow | Implemented |
| Google Maps integration | Implemented |
| Gemini recommendation layer | Integration foundation present; recommendation UX is roadmap |
| 5–7 destinations per region | Starter-batch plan defined; staged import in progress |

**Visual:** Clean checklist with a “Built” stamp and a small “Next” ribbon for roadmap items.

## Slide 7 — Technology architecture
### A practical stack designed to scale from prototype to product
**Frontend:** React 19, Tailwind, shadcn/ui, responsive photo-first experience.

**Application layer:** Express and tRPC for typed contracts between UI and server.

**Data layer:** Drizzle ORM with MySQL/TiDB for users, regions, destinations, galleries, itineraries, trip stops, hotels, bookings, and travel agents.

**Experience services:** Google Maps for location context and route-ready map services; Gemini foundation for future recommendation workflows; S3-backed asset storage for images.

**Safety and quality:** Protected procedures enforce itinerary ownership; generated or pending image states avoid assigning unrelated photos; backend tests cover core travel APIs.

**Visual:** Layered architecture diagram from traveler → React UI → tRPC → database/services.

## Slide 8 — The differentiation
### TravelBharat is built for the long tail of India
The product does not stop at famous monuments. Its catalogue model supports beaches, temples, forts, waterfalls, picnic spots, hills, small cities, heritage sites, and region-specific experiences.

The Goa validation batch already demonstrates the operating model: distinct destination records, coordinates, categories, galleries, image provenance, and explicit pending-photo states. The nationwide plan uses a transparent 5–7 destination starter batch for each represented region before deeper expansion.

**Visual:** A map-like constellation of categories, with Goa highlighted as the first validated batch.

## Slide 9 — Trust, transparency, and responsible AI
### Useful technology without pretending certainty
TravelBharat separates verified factual data from generated editorial visuals. Generated images are owned by the project and documented as illustrations; they are not presented as documentary photographs. Hotel and agent contacts remain hidden until verified records exist. Booking is clearly sandboxed in the prototype.

**Trust principles:**

- No fabricated reviews, ratings, or testimonials.
- No invented hotel or agent contact details.
- No unrelated image reused for another destination.
- Ownership-safe itinerary mutations.
- Clear distinction between implemented features and future roadmap.

**Visual:** Three trust cards: “Verified data,” “Owned visuals,” and “Sandbox action.”

## Slide 10 — Value and business pathway
### From discovery utility to a travel-finance opportunity
TravelBharat can create value for travelers, local partners, and a financial-services ecosystem:

**Traveler:** less search friction, better trip confidence, and a single planning surface.

**Local partner:** structured visibility for hotels, agents, and emerging destinations.

**Platform:** qualified travel intent, itinerary signals, and a foundation for contextual offers or financing journeys—subject to consent, compliance, and future partner validation.

This deck does not claim live lending, live payment processing, or commercial conversion. It presents the product surface where those future integrations could responsibly connect.

**Visual:** Three-sided value triangle.

## Slide 11 — Roadmap and success measures
### Build the national index, then make it intelligent
**0–30 days:** Complete 5–7 source-backed destinations for every region; add approved photos and coordinates; finish mobile accessibility audit.

**31–60 days:** Expand hotel and agent records, improve map routes, add import review tools, and complete Gemini recommendation UX.

**61–90 days:** Introduce consent-based partner journeys, analytics, itinerary sharing, and carefully evaluated travel-finance integrations.

**Success measures:** destination coverage, image completeness, search-to-detail engagement, itinerary creation rate, stop-add rate, booking-request completion, and user-reported confidence.

**Visual:** Three-stage road with measurable checkpoints.

## Slide 12 — Close and demo invitation
### Make every Indian journey easier to begin.
TravelBharat turns a fragmented travel search into a confident, visual, actionable journey.

**Live prototype:** Use the current TravelBharat project preview link.

**Demo order:** Homepage search → Goa Discover results → destination detail/map → Plan Trip → hotel/agent sections → sandbox booking request.

**Closing line:** “The future of travel discovery is not more lists. It is better decisions, made possible by better context.”

**Speaker cue:** Invite the jury to choose a destination and watch the system build the journey around it.

## References

[1] [TVS Credit E.P.I.C. 8.0 — IT Challenge, Unstop](https://unstop.com/competitions/crp-tvs-credit-epic-80-it-challenge-epic-season-8-tvs-credit-1701115)

[2] [Incredible India — Destinations](https://www.incredibleindia.gov.in/en/destinations)

## Presenter notes

Keep the demo under three minutes. Do not claim that every Indian destination, hotel contact, or agent record is complete; explain that the scalable data model and staged starter-batch workflow are the proof of concept. When discussing Gemini, describe it as an integration foundation and roadmap recommendation layer unless the live recommendation UX has been separately verified.
