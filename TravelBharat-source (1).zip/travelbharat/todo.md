# Project TODO

- [x] Create TravelBharat public landing page and navigation
- [x] Add state directory and destination catalogue
- [x] Add destination detail pages with travel information
- [x] Add destination search and category filters
- [x] Add live map display for destination locations
- [x] Add user authentication and session-aware navigation
- [ ] Add favorites and itinerary planning
- [ ] Add reviews and ratings without fabricated testimonials
- [ ] Add administrator dashboard and destination CRUD operations
- [ ] Add sandbox payment flow for tour or itinerary booking
- [x] Add machine-learning destination recommendation feature
- [ ] Add responsive styling, validation, loading states, and error states
- [x] Add Vitest coverage for tourism procedures
- [ ] Test the complete application and fix defects
- [ ] Prepare project documentation, screenshots, diagrams, and presentation materials
- [x] Wire landing-page CTA buttons to real routes/actions or add explicit coming-soon handling instead of inert buttons
- [x] Add accessible mobile navigation for the public landing page and verify navigation works across screen sizes
- [x] Wire the Sign in CTA to the real auth flow, or rename it and point it to a matching destination/coming-soon interaction
- [ ] Verify the mobile menu open/close interaction with an expanded-menu capture
- [x] Implement a real state directory with clickable state cards plus state detail and browse routes
- [x] Implement destination detail routes/pages so catalogue results do not dead-end
- [x] Move destination and state data into the app data layer/database and wire catalogue/filter UI to it
- [x] Add loading, empty, and error handling for catalogue and filter views and verify filtered navigation end-to-end
- [x] Wire or remove the inert Add to itinerary and Save destination controls on destination detail pages
- [x] Replace placeholder destination-detail copy with the travel fields actually delivered
- [x] Implement state and destination catalogue data through the real database schema, helpers, and tRPC procedures
- [x] Add loading, error, and empty states for catalogue and destination detail pages backed by fetched data
- [x] Fix search and category filtering so both constraints are combined correctly, then verify filtered results and detail navigation
- [x] Implement the first destination recommendation logic and add focused Vitest coverage for it
- [x] Rename the completed tourism test item if recommendation work remains separate from procedure coverage
- [x] Create a beginner-friendly standalone TravelBharat HTML homepage with inline CSS and basic interactions
- [x] Preview the starter HTML homepage and verify its responsive layout
- [x] Preview a seeded destination detail page and verify the live map and marker render correctly
- [x] Add a user-facing map-load fallback when the map script fails or initialization cannot complete
- [ ] Capture a destination-detail map view that clearly demonstrates the seeded destination marker is rendered
- [ ] Verify the authenticated browser state and exercise the sign-out action end-to-end
- [x] Add a shared session-aware public header across Discover, States, and DestinationDetail
- [x] Make the authenticated account control explicitly communicate sign-out behavior
- [x] Extract the complete official problem statement from the uploaded screen recording
- [x] Compare the official requirements with the current TravelBharat implementation
- [x] Revise the 15-day roadmap and feature priorities based on the recording
- [ ] Implement any newly required modules identified in the recording
- [ ] Add city, historical significance, entry fee, opening timings, nearby attractions, and moderation fields to destinations
- [x] Add a destination gallery model and seed accessible gallery content
- [x] Render the complete structured destination details and gallery on the destination page
- [x] Create reusable TravelBharat project workflow skill with initialization, implementation, verification, and delivery guidance
- [x] Validate the reusable TravelBharat skill package
- [x] Add booking form section to the standalone TravelBharat HTML homepage
- [x] Add user login section to the standalone TravelBharat HTML homepage
- [x] Add accessible success and validation behavior for booking and login forms
- [x] Recheck the updated standalone HTML homepage on desktop and mobile
- [ ] Define country, state/region, and picnic-spot search taxonomy
- [ ] Identify approved live or regularly refreshed sources for real prices and record freshness timestamps
- [ ] Extend the data model for countries, regions, picnic spots, price types, currencies, and source attribution
- [ ] Add one unified search experience across all destination levels
- [ ] Display real prices with currency, source, last-updated time, and unavailable states
- [ ] Avoid presenting seeded or estimated prices as live real prices
- [x] Cover all Indian states and union territories in the destination taxonomy
- [ ] Define the real-price second option as sourced destination entry fees, travel services, or both
- [ ] Add source attribution and last-updated metadata to every displayed real price
- [ ] Avoid showing estimated or seeded values as verified real prices
- [ ] Support source-backed entry-ticket prices for tourist and picnic spots
- [ ] Support source-backed hotel prices with dates, currency, provider, and last-updated metadata
- [ ] Support source-backed transport prices with route/date context, currency, provider, and last-updated metadata
- [ ] Add explicit unavailable or API-not-connected states instead of fabricating price results
- [x] Request and validate the Google Gemini API key through a lightweight server-side health check
- [x] Integrate Gemini server-side for explainable destination recommendations or travel assistance
- [ ] Obtain and validate separate provider sources for live hotel and transport prices
- [x] Add explicit accessible client-side validation states and messages for booking and login fields
- [x] Clarify the standalone login form as demo-only and avoid implying production authentication
- [x] Fix duplicate Google Maps JavaScript API loading on the homepage and verify the shared loader
- [x] Remove platform-specific branding from user-facing TravelBharat UI and metadata where possible
- [x] Expand the catalogue with Mumbai, Nashik, historical places, and temple destinations
- [x] Add photo fields and destination image assets for the expanded catalogue with safe attribution handling
- [x] Add broader destination categories for hills, beaches, picnic spots, adventure, waterfalls, and city experiences
- [x] Add Anjaneri Hills, Brahmagiri Hills, Chandwad, Harihar Fort, Kokan destinations, beaches, and Udaipur photo-first entries
- [x] Make primary destination imagery the first visual people see on discovery and detail pages, including Udaipur
- [x] Add photo galleries for the broader destination set with provenance and accessible alt text
- [x] Add a Waterfall category filter and a verified waterfall destination entry with photo and gallery
- [x] Exercise the Waterfall filter end-to-end and confirm Randha Falls appears with its photo
- [x] Verify the Randha Falls detail gallery and accessible alt text in the user-facing page
- [x] Recheck that the generated Randha Falls asset resolves as a real image rather than a placeholder
- [x] Audit all destination rows for missing primary images
- [x] Add real image assets to every destination card, including Darjeeling and older records
- [x] Verify the complete discovery catalogue shows an image before every destination name
- [x] Replace unverified search images with TravelBharat-owned generated assets for Darjeeling, Manali, Munnar, Panaji, and Varanasi
- [x] Update image provenance documentation to match the owned generated assets used in the database
- [x] Read and verify image-source-notes.md against the current destination and gallery image URLs for the five owned replacement destinations
- [x] Add an auditable provenance table listing each destination slug with its primary and gallery image URLs
- [x] Re-verify the full discovery catalogue after the owned image replacement
- [x] Define a nationwide state and union-territory coverage inventory
- [ ] Add smaller destinations across every state and union territory in batches
- [x] Replace homepage state-card gradient-only visuals with real state-specific destination images
- [x] Verify homepage state cards show images above the state names on desktop and mobile
- [x] Verify homepage state cards on a mobile viewport and confirm image readability
- [x] Replace gradient-only featured destination cards on the homepage with real photos for Udaipur, Munnar, Manali, and Panaji
- [x] Verify every homepage destination card shows an image before its name and details on desktop and mobile
- [x] Replace the homepage featured-journey hero gradient with a real Rajasthan/Udaipur travel image
- [x] Verify hero image loading and overlay text readability on desktop and mobile
- [x] Make the photo-backed Rajasthan hero panel clickable to the Udaipur destination detail route
- [x] Fix destination-detail hero rendering so the stored primary image appears instead of a gradient
- [x] Verify the Udaipur detail hero and gallery both use the same location-specific image
- [x] Add a second Maharashtra small-place batch: Bhandardara, Igatpuri, Matheran, Alibaug, and Bhimashankar
- [x] Replace recycled category-level images on new nationwide destinations with destination-appropriate owned or license-verified images
- [x] Run a full audit that every destination gallery image matches its final primary image
- [x] Recheck representative destination detail pages for hero and gallery consistency
- [x] Fix state-detail destination cards so their primary images render reliably instead of fallback gradients
- [x] Fix duplicate image assignments so each destination name maps to its own location-specific image
- [x] Synchronize each destination gallery with its corrected primary image
- [x] Verify no image path is shared by different destination names
- [x] Verify accessible gallery alt text after the destination image corrections
- [x] Run a clear nationwide verification pass with exact counts and an end-to-end search test
- [x] Re-run full discovery QA and confirm no destination card shows another location’s image
- [x] Complete destination-specific image replacement for every remaining nationwide destination using recycled or shared imagery
- [x] Produce a definitive destination-to-gallery image consistency report after all corrections
- [x] Verify multiple corrected detail pages and rendered gallery alt attributes in the browser
- [x] Ensure every new destination has a primary image and accessible image metadata
- [x] Verify nationwide state coverage, destination counts, search, and image completeness
- [x] Run an end-to-end browser search verification on the nationwide catalogue and record the result
- [x] Fix homepage search to include destination names and navigate to matching Discover results
- [x] Fix Discover result cards so their primary destination images render immediately above the destination names
- [x] Initialize the Discover search field from a URL query parameter for shareable search results
- [x] Add backend-supported Featured Destinations selection for the homepage
- [x] Build a responsive Featured Destinations carousel with real destination images
- [x] Verify carousel controls, keyboard access, mobile layout, and destination navigation
- [x] Exercise Featured Destinations previous/next controls at normal and boundary states
- [x] Fix Featured Destinations pagination when the backend returns fewer than the curated slug list
- [x] Open a featured destination card and verify it lands on the correct detail page
- [x] Perform a keyboard-only carousel and destination-link check and record the result
- [x] Click a Featured Destinations card link from the homepage and verify it opens the matching destination detail page
- [x] Perform a true keyboard-only carousel test: focus controls, activate a control, focus a destination link, and open it via keyboard
- [ ] Perform a real keyboard-only homepage test without console scripting using Tab/Shift+Tab and Enter or Space
- [ ] Capture visible focus and resulting navigation during the true keyboard-only Featured Destinations flow
- [x] Add authenticated itinerary and trip-stop backend data models
- [x] Add persisted live-map route data and Plan Trip API procedures
- [ ] Expand destination galleries to at least 10 photos per selected destination
- [x] Add structured hotel contacts, booking links, pricing fields, and photos
- [ ] Build and verify Plan Trip, gallery, hotel, and live-map UI flows

- [ ] Audit the full Discover result set for semantic destination-to-image correctness
- [ ] Finish replacing any remaining unverified/search-sourced image records and update provenance
- [ ] Generate a per-destination image consistency report with slug, primary image, gallery image, and mismatch status
- [x] Add deterministic Discover card image load/error handling so primary photos reliably display instead of fallback gradients
- [x] Verify multiple Discover results on desktop and mobile with visible primary images above destination names

### Current iteration
- [x] Run an end-to-end browser search verification on the nationwide catalogue and record the result
- [x] Fix homepage search to include destination names and navigate to matching Discover results
- [x] Strengthen Discover result image rendering with explicit load/error handling
- [x] Verify multiple Discover result images on desktop and mobile
- [x] Save a checkpoint for the verified Discover image fix

- [x] Implement authenticated Plan Trip UI connected to itinerary and trip-stop APIs
- [x] Implement admin moderation module using the existing role-based backend pattern
- [x] Integrate Gemini recommendations into the destination experience
- [ ] Expand selected destination galleries to 10+ photos
- [x] Add structured hotel contacts, prices, booking links, and photos to destination details
- [ ] Complete keyboard accessibility and mobile responsiveness audit
- [ ] Save a final feature checkpoint after verification

### Current iteration completed
- [x] Fix Discover result cards so their primary destination images render immediately above the destination names
- [x] Verify Udaipur search result photo appears above the destination name on desktop
- [x] Verify homepage Featured Destinations next control is interactive
- [x] TypeScript check and all 9 Vitest tests pass

### Current iteration remaining
- [x] Implement deterministic image load/error state rather than relying only on eager loading
- [x] Verify multiple Discover cards on desktop and mobile after the stateful image fix
- [x] Save a checkpoint after the verification pass

### Next feature sequence
- [x] Build Plan Trip UI for authenticated itinerary creation and trip-stop management
- [x] Add admin moderation UI and protected content workflows
- [x] Integrate Gemini recommendations with explainable result states
- [ ] Expand galleries and hotel contact data for selected destinations
- [ ] Perform final keyboard and responsive audit
- [ ] Save final checkpoint

### Current iteration status
- [x] Homepage search routes Udaipur to Discover with query preserved
- [x] Discover Udaipur card visibly renders the primary Udaipur image above the name
- [x] Featured carousel control can be activated from the homepage
- [x] TypeScript and Vitest verification completed

### Current implementation gap to close
- [x] Add explicit image loading/error state to Discover cards
- [x] Verify image state across multiple search results and mobile viewport
- [x] Save a checkpoint after closing the gap

### Next planned feature
- [x] Build Plan Trip UI connected to existing protected itinerary and trip-stop procedures
- [ ] Verify authenticated Plan Trip flow
- [ ] Continue with admin, Gemini, gallery, and hotel modules
- [x] Add a visible loading state for Discover card images alongside the explicit error state
- [x] Re-verify Discover cards after the visible loading-state update
- [x] Save a checkpoint after the final Discover image verification

### New user-requested Explore and Plan Trip scope
- [x] Add authenticated Explore/Plan a Trip frontend route connected to itinerary creation and trip-stop APIs
- [x] Add travel-agent contact data model and backend procedures with phone/email/availability fields
- [x] Add destination-linked hotel data with contact number, email, booking URL, price range, and image fields
- [x] Show hotel options inside planned-trip destination cards
- [x] Add agent contact actions to the Explore/Plan a Trip flow
- [x] Add backend tests for agent and hotel-linked planning data
- [x] Verify Explore and Plan a Trip flows on desktop and mobile
- [x] Save a checkpoint after the Explore and Plan Trip milestone
- [x] Prevent mobile Plan Trip header actions from wrapping awkwardly

### Plan Trip verification gaps
- [ ] Add verified destination-linked hotel records without fabricating contact data
- [ ] Render hotel photo and email fields wherever hotel records exist
- [x] Add focused tests for itinerary detail enrichment, destination-specific hotel/agent lookup, and ownership safety
- [ ] Perform authenticated browser verification for itinerary creation, adding a stop, hotel/agent sections, and booking request

### Goa-first state directory expansion
- [x] Audit the destination schema and existing Goa records for coordinates, categories, practical details, and image provenance
- [ ] Create a verified inventory of at least 50 distinct Goa visiting spots with source notes
- [ ] Add Goa destinations with unique destination-to-image mapping and accurate coordinates
- [x] Add Goa state browsing and filtering that exposes all destination records
- [ ] Verify each Goa card and detail page shows the matching photo before the name and location
- [x] Document a repeatable state-by-state import workflow for nationwide expansion

### Nationwide destination directory scope
- [x] Define destination coverage targets for all 28 states and 8 union territories
- [x] Build a reusable source-backed import format for region, destination, coordinates, category, practical details, and image provenance
- [ ] Expand every Indian region in staged batches rather than limiting the catalogue to Goa
- [x] Add region-level counts and completeness indicators to the directory
- [ ] Verify that every imported destination maps to its own photo and location
- [x] Update homepage coverage copy to report all represented Indian regions, including union territories, accurately
- [x] Add a source-backed destination batch schema and validator for repeatable regional imports

### TravelBharat-owned generated image policy
- [x] Generate destination-specific TravelBharat-owned cover images for approved regional destination records
- [x] Store generated image provenance and destination-to-image mappings without reusing the wrong location image
- [x] Add a concise project-level note that catalogue visuals are generated illustrations, not documentary photographs
- [ ] Verify generated images render before destination names across homepage, state, Discover, and detail cards
- [x] Initialize Discover search field from the URL query parameter for shareable regional and destination searches
- [x] Fix Discover search to return destinations when the query matches their state or region name
- [x] Publish explicit staged destination-count targets for each represented state and union territory
- [x] Show the selected region’s current destination count and photo-completeness status on its detail page

### Uploaded Goa source expansion
- [x] Extract Goa place names and source links from the uploaded HTML file
- [x] Match extracted places to existing Goa destination records and identify new records
- [x] Prepare a destination-specific main-photo manifest for extracted places
- [ ] Add only reusable or user-provided main photos and keep missing assets explicitly pending
- [ ] Validate unique destination-to-photo mappings and verify Goa rendering after synchronization

### Nationwide 5–7 destination starter batch
- [x] Define the exact 36-region starter-batch coverage and source-quality rules
- [ ] Normalize 5–7 source-backed destination records for each represented state and union territory
- [ ] Import starter-batch records with accurate coordinates, categories, and practical details
- [ ] Map unique reusable, user-provided, or explicitly pending visuals for each starter destination
- [ ] Verify region counts, state-name search, photo-first cards, and missing-image indicators across all regions

### TVS Credit E.P.I.C. 8.0 hackathon deliverables
- [ ] Create a TVS Credit E.P.I.C. 8.0 pitch deck for TravelBharat with a compelling problem-solution narrative
- [ ] Include a prototype user journey covering Discover, destination detail, maps, Plan Trip, hotels, agents, and sandbox booking
- [ ] Separate implemented capabilities from roadmap capabilities such as Gemini recommendations and nationwide expansion
- [ ] Add architecture, impact, business model, risks, roadmap, and demo-script slides grounded in the current project
- [ ] Use the provided challenge screenshots and TravelBharat visual assets appropriately in the deck
- [ ] Generate and verify the presentation deliverable and supporting prototype/demo guide

### TVS deck revision
- [x] Correct the TVS Credit name and Round 2 case-study wording in the deck
- [x] Strengthen jury-facing problem-solution-impact framing and prototype demo emphasis
- [ ] Regenerate speaker notes and present the revised deck

### TVS deck visual enhancement
- [ ] Add selected TravelBharat-owned destination images to the cover and solution narrative
- [ ] Add TravelBharat prototype screenshots to the prototype walkthrough and evidence slides
- [ ] Rebalance layouts so added visuals remain readable and jury-focused

### Visual editor repair verification
- [x] Remove duplicate inline style props injected into Home.tsx
- [x] Preserve the intended 36px rounded Plan section and 23px top padding
- [x] Run TypeScript and all 13 Vitest tests
- [x] Verify the homepage visually on desktop after the repair
- [x] Save checkpoint for the visual-editor repair
- [x] Verify the repaired homepage Plan section at 390px mobile width without overflow

### Hotels and transportation expansion
- [x] Audit existing hotel fields, itinerary procedures, and any current pricing or availability states
- [x] Add a transport option data model with route, mode, provider, timing, fare, currency, source, and last-updated fields
- [x] Add public transport lookup procedures with explicit unavailable/live-data states
- [x] Provide hotel and transport discovery through destination details and Plan Trip, with Discover-to-Plan handoff
- [x] Link selected hotel and transport options to an authenticated itinerary
- [x] Add truthful price/source/freshness labels and avoid fabricated live prices
- [ ] Verify hotel and transport flows on desktop and mobile with an authenticated stop-selection session
- [x] Save the hotels and transportation milestone checkpoint

- [x] Add transportation data model for flights, trains, buses, and local rentals with source and availability fields
- [x] Generate and apply the transportation database migration
- [x] Add transportation database helpers and public tRPC lookup procedures
- [x] Surface hotel and transportation options in the authenticated Plan Trip flow
- [x] Show explicit source, freshness, and unavailable states for service pricing and availability
- [x] Add transportation procedure tests and verify existing hotel/itinerary behavior
- [x] Run TypeScript, Vitest, and responsive browser verification for the integrated Plan Trip flow

- [x] Add a direct Plan Trip entry point from public Discover destination cards

- [x] Add an authenticated Plan Trip live route overview using existing MapView and saved-stop coordinates

- [x] Remove unsupported homepage traveller rating language and replace it with factual catalogue messaging

- [x] Replace unsupported homepage featured-card budget figures with an explicit price-not-published state

- [x] Add protected admin moderation queue and destination status-update procedures with authorization tests

- [x] Add role-aware /admin moderation UI with queue preview, publish, and needs-review actions

- [x] Fix /admin unauthenticated handling with a clear sign-in prompt and timeout fallback
- [x] Verify anonymous /admin access resolves to an explicit admin sign-in state
- [ ] Verify /admin with non-admin and administrator sessions, including queue actions

- [ ] Populate hotel records only from verified provider or official source data; current database audit found 0 hotel rows

- [x] Expose an ownership-safe protected route-overview procedure for saved itinerary stops
- [x] Add route-overview authorization coverage to the trip API tests

- [x] Prepare and deliver a complete TravelBharat source package with setup instructions

- [x] Make the development startup script cross-platform for Windows PowerShell and Command Prompt

- [x] Move pnpm patched-dependency and override configuration to the supported workspace configuration format

- [x] Prevent malformed analytics requests when optional local analytics environment variables are missing
- [x] Document which local environment variables are required for public pages versus authentication features

- [x] Fix malformed analytics-loader regular expression causing Invalid regular expression flags on the homepage

- [ ] Refresh and revalidate the downloadable source archive after the homepage regex repair
