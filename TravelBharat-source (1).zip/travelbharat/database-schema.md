# TravelBharat Database Schema

The current TravelBharat schema is written with **Drizzle ORM** for a MySQL-compatible database.

## Schema code

```ts
import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const states = mysqlTable("states", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  description: text("description").notNull(),
  capital: varchar("capital", { length: 120 }),
  image: text("image"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const destinations = mysqlTable("destinations", {
  id: int("id").autoincrement().primaryKey(),
  stateId: int("stateId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  category: varchar("category", { length: 80 }).notNull(),
  description: text("description").notNull(),
  budget: varchar("budget", { length: 40 }).notNull(),
  bestSeason: varchar("bestSeason", { length: 120 }),
  latitude: varchar("latitude", { length: 32 }),
  longitude: varchar("longitude", { length: 32 }),
  highlights: text("highlights"),
  image: text("image"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type State = typeof states.$inferSelect;
export type InsertState = typeof states.$inferInsert;
export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = typeof destinations.$inferInsert;
```

## Tables

### `users`

Stores authenticated users created through the project authentication flow. The `role` column separates normal users from administrators.

### `states`

Stores Indian state or region information displayed in the state directory. Each state has a unique name and can contain multiple destinations.

### `destinations`

Stores tourist-place information. The `stateId` column identifies the associated state. The table also contains the category, description, estimated budget, best season, map coordinates, highlights, and optional image reference.

## Relationship

The intended relationship is:

```text
states 1 ────────────< destinations

One state can contain many destinations.
Each destination belongs to one state through destinations.stateId.
```

The current schema stores `stateId` as an integer and the application joins it to `states.id` in the database query helpers. A formal database foreign-key constraint can be added in a later migration if required by the internship specification.

## Current data examples

The seeded catalogue currently includes states such as Rajasthan, Kerala, Himachal Pradesh, Goa, Uttar Pradesh, and West Bengal. Destinations include Udaipur, Munnar, Manali, Panaji, Varanasi, and Darjeeling.

## Planned future tables

To support the remaining project requirements, the next planned tables are `favorites`, `itineraries`, `reviews`, `bookings`, and `payments`. Map coordinates are already present in `destinations`, while payment records and booking status will be added when the sandbox payment flow is implemented.
