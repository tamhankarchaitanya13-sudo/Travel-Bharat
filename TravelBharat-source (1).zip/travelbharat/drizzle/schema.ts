import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const states = mysqlTable("states", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull().unique(),
  description: text("description").notNull(),
  capital: varchar("capital", { length: 120 }),
  image: text("image"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const destinations = mysqlTable("destinations", {
  id: int("id").autoincrement().primaryKey(),
  stateId: int("stateId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  category: varchar("category", { length: 80 }).notNull(),
  description: text("description").notNull(),
  city: varchar("city", { length: 120 }),
  historicalSignificance: text("historicalSignificance"),
  entryFee: varchar("entryFee", { length: 80 }),
  openingHours: varchar("openingHours", { length: 160 }),
  nearbyAttractions: text("nearbyAttractions"),
  budget: varchar("budget", { length: 40 }).notNull(),
  bestSeason: varchar("bestSeason", { length: 120 }),
  latitude: varchar("latitude", { length: 32 }),
  longitude: varchar("longitude", { length: 32 }),
  highlights: text("highlights"),
  image: text("image"),
  moderationStatus: mysqlEnum("moderationStatus", ["draft", "published", "needs_review"]).default("published").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const destinationGallery = mysqlTable("destinationGallery", {
  id: int("id").autoincrement().primaryKey(),
  destinationId: int("destinationId").notNull(),
  imageUrl: text("imageUrl").notNull(),
  altText: varchar("altText", { length: 240 }).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type State = typeof states.$inferSelect;
export type InsertState = typeof states.$inferInsert;
export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = typeof destinations.$inferInsert;
export const itineraries = mysqlTable("itineraries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  startDate: varchar("startDate", { length: 32 }),
  endDate: varchar("endDate", { length: 32 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["draft", "planned", "completed"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const itineraryItems = mysqlTable("itineraryItems", {
  id: int("id").autoincrement().primaryKey(),
  itineraryId: int("itineraryId").notNull(),
  destinationId: int("destinationId").notNull(),
  dayNumber: int("dayNumber").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  notes: text("notes"),
  hotelId: int("hotelId"),
  transportationId: int("transportationId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  itineraryId: int("itineraryId"),
  destinationId: int("destinationId"),
  travelerName: varchar("travelerName", { length: 160 }).notNull(),
  travelerEmail: varchar("travelerEmail", { length: 320 }).notNull(),
  travelersCount: int("travelersCount").default(1).notNull(),
  travelDate: varchar("travelDate", { length: 32 }),
  status: mysqlEnum("status", ["requested", "confirmed", "cancelled"]).default("requested").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const travelAgents = mysqlTable("travelAgents", {
  id: int("id").autoincrement().primaryKey(),
  destinationId: int("destinationId"),
  name: varchar("name", { length: 180 }).notNull(),
  phone: varchar("phone", { length: 64 }),
  whatsapp: varchar("whatsapp", { length: 64 }),
  email: varchar("email", { length: 320 }),
  availability: varchar("availability", { length: 160 }),
  specialties: text("specialties"),
  bookingUrl: text("bookingUrl"),
  image: text("image"),
  moderationStatus: mysqlEnum("moderationStatus", ["draft", "published", "needs_review"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const hotels = mysqlTable("hotels", {
  id: int("id").autoincrement().primaryKey(),
  destinationId: int("destinationId").notNull(),
  name: varchar("name", { length: 180 }).notNull(),
  address: text("address"),
  contactPhone: varchar("contactPhone", { length: 64 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  websiteUrl: text("websiteUrl"),
  bookingUrl: text("bookingUrl"),
  priceRange: varchar("priceRange", { length: 80 }),
  image: text("image"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const transportation = mysqlTable("transportation", {
  id: int("id").autoincrement().primaryKey(),
  destinationId: int("destinationId"),
  mode: mysqlEnum("mode", ["flight", "train", "bus", "local_rental"]).notNull(),
  provider: varchar("provider", { length: 180 }).notNull(),
  route: varchar("route", { length: 240 }),
  departureLocation: varchar("departureLocation", { length: 160 }),
  arrivalLocation: varchar("arrivalLocation", { length: 160 }),
  departureTime: varchar("departureTime", { length: 80 }),
  arrivalTime: varchar("arrivalTime", { length: 80 }),
  contactPhone: varchar("contactPhone", { length: 64 }),
  websiteUrl: text("websiteUrl"),
  bookingUrl: text("bookingUrl"),
  fare: varchar("fare", { length: 80 }),
  currency: varchar("currency", { length: 8 }).default("INR"),
  priceSource: text("priceSource"),
  priceUpdatedAt: varchar("priceUpdatedAt", { length: 40 }),
  availability: mysqlEnum("availability", ["available", "limited", "unknown", "unavailable"]).default("unknown").notNull(),
  image: text("image"),
  description: text("description"),
  moderationStatus: mysqlEnum("moderationStatus", ["draft", "published", "needs_review"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DestinationGallery = typeof destinationGallery.$inferSelect;
export type InsertDestinationGallery = typeof destinationGallery.$inferInsert;
export type Itinerary = typeof itineraries.$inferSelect;
export type InsertItinerary = typeof itineraries.$inferInsert;
export type ItineraryItem = typeof itineraryItems.$inferSelect;
export type InsertItineraryItem = typeof itineraryItems.$inferInsert;
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = typeof bookings.$inferInsert;
export type Hotel = typeof hotels.$inferSelect;
export type InsertHotel = typeof hotels.$inferInsert;
export type Transportation = typeof transportation.$inferSelect;
export type InsertTransportation = typeof transportation.$inferInsert;
export type TravelAgent = typeof travelAgents.$inferSelect;
export type InsertTravelAgent = typeof travelAgents.$inferInsert;
