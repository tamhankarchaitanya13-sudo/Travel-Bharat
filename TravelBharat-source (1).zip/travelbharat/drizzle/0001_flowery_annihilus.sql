CREATE TABLE `destinations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stateId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`slug` varchar(180) NOT NULL,
	`category` varchar(80) NOT NULL,
	`description` text NOT NULL,
	`budget` varchar(40) NOT NULL,
	`bestSeason` varchar(120),
	`latitude` varchar(32),
	`longitude` varchar(32),
	`highlights` text,
	`image` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `destinations_id` PRIMARY KEY(`id`),
	CONSTRAINT `destinations_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `states` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` text NOT NULL,
	`capital` varchar(120),
	`image` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `states_id` PRIMARY KEY(`id`),
	CONSTRAINT `states_name_unique` UNIQUE(`name`)
);
