CREATE TABLE `travelAgents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`destinationId` int,
	`name` varchar(180) NOT NULL,
	`phone` varchar(64),
	`whatsapp` varchar(64),
	`email` varchar(320),
	`availability` varchar(160),
	`specialties` text,
	`bookingUrl` text,
	`image` text,
	`moderationStatus` enum('draft','published','needs_review') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `travelAgents_id` PRIMARY KEY(`id`)
);
