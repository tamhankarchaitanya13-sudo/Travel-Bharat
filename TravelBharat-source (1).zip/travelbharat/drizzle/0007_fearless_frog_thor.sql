ALTER TABLE `itineraryItems` ADD `hotelId` int;--> statement-breakpoint
ALTER TABLE `itineraryItems` ADD `transportationId` int;