CREATE TABLE `destinationGallery` (
	`id` int AUTO_INCREMENT NOT NULL,
	`destinationId` int NOT NULL,
	`imageUrl` text NOT NULL,
	`altText` varchar(240) NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `destinationGallery_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `destinations` ADD `city` varchar(120);--> statement-breakpoint
ALTER TABLE `destinations` ADD `historicalSignificance` text;--> statement-breakpoint
ALTER TABLE `destinations` ADD `entryFee` varchar(80);--> statement-breakpoint
ALTER TABLE `destinations` ADD `openingHours` varchar(160);--> statement-breakpoint
ALTER TABLE `destinations` ADD `nearbyAttractions` text;--> statement-breakpoint
ALTER TABLE `destinations` ADD `moderationStatus` enum('draft','published','needs_review') DEFAULT 'published' NOT NULL;--> statement-breakpoint
ALTER TABLE `destinations` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;