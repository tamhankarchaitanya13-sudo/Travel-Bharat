ALTER TABLE `transportation` ADD `departureTime` varchar(80);--> statement-breakpoint
ALTER TABLE `transportation` ADD `arrivalTime` varchar(80);