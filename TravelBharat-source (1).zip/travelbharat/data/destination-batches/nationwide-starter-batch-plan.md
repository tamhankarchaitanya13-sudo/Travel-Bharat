# TravelBharat Nationwide Starter-Batch Plan

This plan starts each represented Indian state and union territory with **5–7 source-backed destinations**. It is a staging plan, not a claim that the records are already imported. Every destination must later receive a verified region relationship, coordinates, category, source URL, practical-data status, and either a destination-specific reusable image or an explicit photo-pending status.

Primary discovery source: [Incredible India Destinations](https://www.incredibleindia.gov.in/en/destinations). National reference: [Ministry of Tourism](https://tourism.gov.in/).

| Region | Kind | Starter range | Status |
|---|---|---:|---|
| Andaman and Nicobar Islands | Union territory | 5–7 | Research pending |
| Andhra Pradesh | State | 5–7 | Research pending |
| Arunachal Pradesh | State | 5–7 | Research pending |
| Assam | State | 5–7 | Research pending |
| Bihar | State | 5–7 | Research pending |
| Chandigarh | Union territory | 5–7 | Research pending |
| Chhattisgarh | State | 5–7 | Research pending |
| Dadra and Nagar Haveli and Daman and Diu | Union territory | 5–7 | Research pending |
| Delhi | Union territory | 5–7 | Research pending |
| Goa | State | 5–7 starter batch; 50+ expansion target | 20+ records already present |
| Gujarat | State | 5–7 | Research pending |
| Haryana | State | 5–7 | Research pending |
| Himachal Pradesh | State | 5–7 | Research pending |
| Jammu and Kashmir | Union territory | 5–7 | Research pending |
| Jharkhand | State | 5–7 | Research pending |
| Karnataka | State | 5–7 | Research pending |
| Kerala | State | 5–7 | Research pending |
| Ladakh | Union territory | 5–7 | Research pending |
| Lakshadweep | Union territory | 5–7 | Research pending |
| Madhya Pradesh | State | 5–7 | Research pending |
| Maharashtra | State | 5–7 | Research pending |
| Manipur | State | 5–7 | Research pending |
| Meghalaya | State | 5–7 | Research pending |
| Mizoram | State | 5–7 | Research pending |
| Nagaland | State | 5–7 | Research pending |
| Odisha | State | 5–7 | Research pending |
| Puducherry | Union territory | 5–7 | Research pending |
| Punjab | State | 5–7 | Research pending |
| Rajasthan | State | 5–7 | Research pending |
| Sikkim | State | 5–7 | Research pending |
| Tamil Nadu | State | 5–7 | Research pending |
| Telangana | State | 5–7 | Research pending |
| Tripura | State | 5–7 | Research pending |
| Uttar Pradesh | State | 5–7 | Research pending |
| Uttarakhand | State | 5–7 | Research pending |
| West Bengal | State | 5–7 | Research pending |

## Acceptance criteria

A region batch is accepted only after the destination names are source-backed, coordinates are verified, duplicate slugs are rejected, image mappings are unique or explicitly pending, and the state directory plus Discover search expose the records. Randomly copied web images, fabricated contact details, and estimated live prices are not acceptable substitutes for verified data.
