# Regional destination batch format

Each region import is a JSON array of destination records. A record is accepted only when it has a stable `slug`, an existing `stateSlug`, a human-readable `name`, a supported `category`, numeric `latitude` and `longitude`, a `primaryImage` URL or WebDev asset URL, and at least one source URL. Optional practical fields include `city`, `description`, `entryFee`, `openingHours`, `nearbyAttractions`, and `sourceLastVerifiedAt`.

The batch format intentionally keeps **source attribution beside each destination**, so a later editor can refresh individual facts without losing provenance. Image URLs must be unique across destination records unless the same image is explicitly documented as a regional overview; destination cards should use a location-specific primary image.

```json
[
  {
    "slug": "fort-aguada",
    "stateSlug": "goa",
    "name": "Fort Aguada",
    "city": "Candolim",
    "category": "Heritage",
    "latitude": 15.4921,
    "longitude": 73.7739,
    "primaryImage": "/manus-storage/fort-aguada-owned.jpg",
    "description": "A Portuguese-era fort and lighthouse complex on the Sinquerim peninsula.",
    "entryFee": null,
    "openingHours": "09:30–18:00",
    "nearbyAttractions": ["Sinquerim Beach", "Candolim Beach"],
    "sources": [
      {
        "url": "https://goa-tourism.com/siteseeing/fort-aguada/",
        "label": "Goa Tourism",
        "lastVerifiedAt": "2026-08-17"
      }
    ]
  }
]
```

`null` is preferred to an invented price. Coordinates should be checked against a reliable map or official listing before insertion. Source-backed batches should be reviewed before any database migration is generated.
